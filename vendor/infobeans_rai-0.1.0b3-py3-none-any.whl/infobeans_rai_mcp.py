# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import asyncio
import os
from pathlib import Path

# Ensure CWD is the project root so relative paths (e.g. logs/, apps/) resolve
# correctly regardless of where Claude Desktop launches this process from.
# When installed as a package (pip install), use INFOBEANS_RAI_WORKSPACE env var.
# When run directly from the project directory, fall back to __file__'s parent.
_workspace = os.environ.get("INFOBEANS_RAI_WORKSPACE") or str(Path(__file__).parent)
os.chdir(_workspace)

from framework.mcp.server import run_server


def main():
    asyncio.run(run_server())


if __name__ == "__main__":
    main()
