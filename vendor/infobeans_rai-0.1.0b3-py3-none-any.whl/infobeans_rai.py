# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import glob
import inspect
import json
import os
import shutil
import subprocess
import sys
from enum import Enum
from pathlib import Path
from typing import List, Optional

import requests as req
import typer
from dotenv import load_dotenv

from framework.core.cli import runner as cli_runner
from framework.core.cli.constants import TYPER_CONTEXT_SETTINGS
from framework.core.cli.enums import DebugLevelTypes, SplitLevelTypes
from framework.core.utils import get_logger, parse_bool
from framework.core.utils.generate_pytest_report import main as report_main
from framework.core.utils.logger import mask_secrets
from framework.core.utils.prepare_email_body import render_email_template
from framework.scaffold_suite.scaffold import create_scaffold

logger = get_logger()

app = typer.Typer(
    pretty_exceptions_enable=False, context_settings=TYPER_CONTEXT_SETTINGS
)


@app.callback()
def callback():
    """QA Runner with dynamic plugin loading for multiple apps."""
    pass  # Main entry point for the Typer app. Initialized when no command is given, to show help.


def get_param_list_for_log(run_command_frame) -> str:
    args = inspect.getargvalues(run_command_frame)
    params_list = [
        f"{k}={args.locals[k].value if isinstance(args.locals[k], Enum) else args.locals[k]}"
        for k in args.args
    ]
    return ",".join(params_list)


@app.command("run")
def run_command(
    app_name: str = typer.Option(
        ...,
        "--app",
        "-a",
        help="App name (e.g., saucedemo or saucedemo-ext). If not provided, runs all apps in `apps` directory under current directory.",
    ),
    config_file: str = typer.Option(
        "config.yaml",
        "--config",
        "-c",
        help="Config file name to use for the app(s).",
    ),
    workers_count: str | None = typer.Option(
        None,
        "--workers-count",
        "-w",
        help="Number of workers to use for parallel processing.",
    ),
    split_level: SplitLevelTypes = typer.Option(
        SplitLevelTypes.TEST_FILE.value,
        "--split-level",
        "-sl",
        help="Way to split files for parallel processing.",
        case_sensitive=True,
    ),
    reruns: int = typer.Option(
        3,
        "--reruns",
        "-rr",
        help="Number of re-run attempts.",
    ),
    reruns_delay: int = typer.Option(
        7,
        "--reruns-delay",
        "-rrd",
        help="Re-run delay in seconds.",
    ),
    debug_level: DebugLevelTypes = typer.Option(
        None, "--debug-level", "-dl", help="Set the debug log level."
    ),
    pytest_extra_args: List[str] = typer.Argument(
        None, help="Additional arguments to pass directly to pytest."
    ),
    generate_allure_report: bool = typer.Option(
        False,
        "--generate-allure-report",
        "-gar",
        help="Generate Allure report after test execution.",
    ),
    single_file_allure_report: bool = typer.Option(
        False,
        "--single-file-allure-report",
        "-sfar",
        help="Generate Allure report as a single HTML file. Requires --generate-allure-report/-gar to be set.",
    ),
    enable_pdb: bool = typer.Option(
        False,
        "--enable-pdb",
        "-pdb",
        help="Enable pdb debugging (disables parallel execution).",
    ),
):
    """Run QA tests for selected app(s) with dynamic plugin loading."""
    if debug_level:
        logger.set_log_level(debug_level.value)

    logger.debug("Loading environment variables from .env file")
    load_dotenv()

    # This value should be set to 'false' in development environments to
    # enable features like pdb debugging.
    IS_WHEEL_BUILD = parse_bool(os.getenv("IS_WHEEL_BUILD", "true"))

    if IS_WHEEL_BUILD:
        # Add the current working directory to sys.path for module resolution
        sys.path.append(os.getcwd())
        if enable_pdb:
            logger.critical(
                "PDB debugging is strictly not available from installed package. Only meant for development environments."
            )
            sys.exit(1)

    repo_root = os.getcwd()
    apps_dir = os.path.join(repo_root, "apps")
    unknown = pytest_extra_args

    logger.info("Starting infobeans-rai Test Runner...")
    # get function params from inspect.currentframe
    logger.debug(f"Params: {get_param_list_for_log(inspect.currentframe())}")

    exit_codes = []
    if app_name:
        exit_code, summary, report = cli_runner.run_app(
            app_name,
            apps_dir,
            reruns=reruns,
            reruns_delay=reruns_delay,
            config_file=config_file,
            extras=unknown,
            split_level=getattr(split_level, "value", split_level),
            workers_count=workers_count,
            generate_allure_report=generate_allure_report,
            single_file_allure_report=single_file_allure_report,
            enable_pdb=enable_pdb,
        )
        exit_codes.append(exit_code)
    else:
        # Run all apps in apps/ folder (skip __init__.py, __pycache__)
        app_names = [
            d.name
            for d in Path(apps_dir).iterdir()
            if d.is_dir() and not d.name.startswith("__")
        ]
        exit_codes = []
        for app_name in app_names:
            exit_code, summary, report = cli_runner.run_app(
                app_name,
                apps_dir,
                reruns=reruns,
                reruns_delay=reruns_delay,
                config_file=config_file,
                extras=unknown,
                split_level=getattr(split_level, "value", split_level),
                workers_count=workers_count,
                generate_allure_report=generate_allure_report,
                single_file_allure_report=single_file_allure_report,
                enable_pdb=enable_pdb,
            )
            exit_codes.append(exit_code)

    logger.info("Completed all tasks.")
    max_exit_code = max(exit_codes)
    # Exit with nonzero if any failed
    if max_exit_code:
        logger.error("Some test-cases have failed.")
        sys.exit(max(exit_codes))


@app.command("setup")
def setup(
    app_name: str = typer.Option(
        ...,
        "--app",
        "-a",
        help="App name (e.g., saucedemo or slack).",
    ),
    scaffold: Optional[str] = typer.Option(
        None,
        "--scaffold",
        "-sc",
        help="Scaffold template: 'true' to copy from existing app structure, 'full' for full template with all test suites, or omit/false for minimal template.",
    ),
    overwrite: bool = typer.Option(
        False,
        "--overwrite",
        help="Overwrite existing app directory if it already exists.",
        is_flag=True,
    ),
):
    """Create a setup with one or more test suites."""

    def _validate_folder_name(name: str, field_name: str) -> None:
        """Validate that folder name contains only alphabets, numbers, and underscores."""
        if not name:
            typer.echo(f"Error: {field_name} cannot be empty.", err=True)
            raise typer.Exit(1)

        # Check if name contains only alphanumeric characters and underscores
        import re

        if not re.match(r"^[a-zA-Z0-9_]+$", name):
            typer.echo(
                f"Error: {field_name} '{name}' contains invalid characters.\n"
                f"Only alphabets (a-z, A-Z), numbers (0-9), and underscores (_) are allowed.",
                err=True,
            )
            raise typer.Exit(1)

        # Check for names that are reserved on Windows
        reserved_names = [
            "CON",
            "PRN",
            "AUX",
            "NUL",
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9",
            "LPT1",
            "LPT2",
            "LPT3",
            "LPT4",
            "LPT5",
            "LPT6",
            "LPT7",
            "LPT8",
            "LPT9",
        ]
        if (
            name.upper() in reserved_names
            or name.upper().split(".")[0] in reserved_names
        ):
            typer.echo(
                f"Error: {field_name} '{name}' is a reserved name on Windows.", err=True
            )
            raise typer.Exit(1)

    # Validate app_name
    if app_name:
        _validate_folder_name(app_name, "App name")

    # Handle existing app directory
    app_dir = Path(os.getcwd()) / "apps" / app_name
    if app_dir.exists():
        if overwrite:
            import shutil
            shutil.rmtree(app_dir)
            typer.echo(f"Existing app '{app_name}' removed. Recreating...")
        else:
            typer.echo(
                f"App '{app_name}' already exists at {app_dir}.\n"
                "Use --overwrite to delete and recreate it.",
                err=True,
            )
            raise typer.Exit(1)

    create_scaffold(app_name, scaffold_template=scaffold)

    if scaffold and scaffold.lower() not in ("false", "0", "no"):
        print(f"Successfully set up app '{app_name}' using scaffold template '{scaffold}'")
    else:
        print(f"Successfully set up app '{app_name}' using minimal template")


@app.command("setup-pipeline")
def setup_pipeline():
    """
    Set up pipeline-related files (.github, requirements.txt, etc.) in the root directory.
    """
    logger.info("Starting pipeline setup...")
    from framework.scaffold_suite.scaffold import setup_pipeline_files
    setup_pipeline_files(Path.cwd())
    print("Successfully set up pipeline files in the root directory.")


@app.command("generate-report", hidden=True)
def generate_report(
    app_name: str = typer.Option(
        None,
        "--app",
        help="App folder name under apps/. Auto-locates apps/<app>/reports/pytest_report.json.",
    ),
    report_title: str = typer.Option(
        "Test Execution Summary",
        "--report-title",
        "--title",
        help="Title for the executive PDF report",
    ),
    detailed: bool = typer.Option(
        False,
        "--detailed",
        help="Include detailed test statistics",
        is_flag=True,
    ),
    results_file: str = typer.Argument(
        None,
        help="Path to pytest results JSON file (not needed when --app is provided)",
    ),
    output: str = typer.Option(
        None,
        "--output",
        "-o",
        help="Output PDF file path",
    ),
):
    """
    Generate executive PDF report from pytest results.
    """
    logger.info("Generating executive report...")

    # Auto-locate results file when --app is provided
    if app_name and not results_file:
        candidate = os.path.join("apps", app_name, "reports", "pytest_report.json")
        if os.path.exists(candidate):
            results_file = candidate
        else:
            typer.echo(f"Error: No results file found at {candidate}", err=True)
            raise typer.Exit(code=1)

    # Simulate CLI invocation expected by generate_pytest_report.main
    sys.argv = ["generate_pytest_report"]

    if results_file:
        sys.argv.append(results_file)

    if output:
        sys.argv.extend(["--output", output])
    elif app_name and results_file:
        # Default output alongside the results file
        default_out = os.path.join("apps", app_name, "reports", "infobeans-rai_test_summary.pdf")
        sys.argv.extend(["--output", default_out])

    sys.argv.extend(["--report-title", report_title])

    if detailed:
        sys.argv.append("--detailed")

    report_main()


@app.command("prepare-email", hidden=True)
def prepare_email(
    template_path: Path = typer.Option(
        ...,
        "--template-path",
        "-t",
        help="Path to email HTML template file",
        exists=True,
        file_okay=True,
        dir_okay=False,
    ),
):
    """
    Generate email body HTML from a template.
    Output is written in the same directory as the template.
    """
    logger.info("Preparing email body...")
    logger.debug(f"Template path: {template_path}")
    output_path = render_email_template(template_path)
    logger.info(f"Email body generated at: {output_path}")
    typer.echo(str(output_path))


@app.command("generate-api-test", hidden=True)
def generate_api_test(
    folder_name: str = typer.Argument(
        "generated_tests",
        help="Name of the folder to create under 'apps/' for generated tests.",
    ),
    schema_url: Optional[str] = typer.Option(
        None,
        "--schemaurl",
        help="URL pointing to the Swagger/OpenAPI schema.",
    ),
    schema_file: Optional[str] = typer.Option(
        None,
        "--schema",
        help="Path to a local Swagger/OpenAPI schema file.",
    ),
):
    """
    Run the API test generator.

    You must provide the API schema via exactly one of:
      --schemaurl   URL to a Swagger/OpenAPI schema
      --schema      Path to a local schema file
    """

    # --- Validate: exactly one of --schemaurl / --schema must be provided ---
    if schema_url and schema_file:
        logger.error("Provide either --schemaurl or --schema, not both.")
        raise typer.Exit(1)

    if not schema_url and not schema_file:
        logger.error(
            "Schema source is required.\n"
            "  Use --schemaurl <URL>   to download from a URL\n"
            "  Use --schema <path>     to use a local schema file"
        )
        raise typer.Exit(1)

    logger.info("Starting API Test Generator...")
    repo_root = os.getcwd()

    # Validation: output folder must be under apps/
    apps_dir = os.path.join(repo_root, "apps")
    target_output_dir = os.path.join(apps_dir, folder_name)

    # The api-test folder is in framework/api-test
    api_test_dir = os.path.join(repo_root, "framework", "api-test")
    script_path = os.path.join(api_test_dir, "run_test_generator.py")

    if not os.path.exists(script_path):
        logger.error(f"Test generator script not found at: {script_path}")
        sys.exit(1)

    # --- Download / copy schema into the api-test workspace ---
    if schema_url:
        try:
            resp = req.get(schema_url, timeout=15)
            resp.raise_for_status()
            # Determine filename from content type
            content_type = resp.headers.get("Content-Type", "")
            ext = ".json" if "json" in content_type else ".yaml"
            local_schema = os.path.join(api_test_dir, f"downloaded_schema{ext}")
            with open(local_schema, "w", encoding="utf-8") as f:
                f.write(resp.text)
            logger.info(f"Downloaded schema from: {schema_url}")
        except Exception as e:
            logger.error(f"Unable to download schema from provided URL: {e}")
            raise typer.Exit(1)
    else:
        if not os.path.isfile(schema_file):
            logger.error(f"Provided schema file does not exist: {schema_file}")
            raise typer.Exit(1)
        local_schema = os.path.join(api_test_dir, os.path.basename(schema_file))
        # Skip copy if src and dest resolve to the same path
        if os.path.abspath(schema_file) != os.path.abspath(local_schema):
            shutil.copy2(schema_file, local_schema)
            logger.info(f"Copied schema from: {schema_file}")
        else:
            logger.info("Schema file is already in workspace — skipping copy.")

    try:
        subprocess.check_call(
            [
                sys.executable,
                script_path,
                "--output",
                target_output_dir,
                "--schema-file",
                local_schema,
            ],
            cwd=api_test_dir,
        )
        logger.info(
            f"API Test Generator completed successfully. Output in: apps/{folder_name}"
        )
    except subprocess.CalledProcessError as e:
        logger.error(f"API Test Generator failed with exit code {e.returncode}")
        sys.exit(e.returncode)


def _find_claude_config_dir(system: str) -> Path:
    """
    Return the Claude Desktop config directory for the current platform,
    handling all known install locations in priority order.
    """
    if system == "Windows":
        local = os.environ.get("LOCALAPPDATA", "")
        appdata = os.environ.get("APPDATA", "")

        candidates = []

        # 1. Microsoft Store (MSIX) install — virtualized AppData.
        #    Check for LocalCache\Roaming set up by Windows (exists once app runs).
        #    The Claude subfolder may not exist yet on a fresh install — that's fine,
        #    we create it with mkdir later.
        if local:
            packages_dir = Path(local) / "Packages"
            if packages_dir.exists():
                for pkg in sorted(packages_dir.glob("Claude_*")):
                    local_cache_roaming = pkg / "LocalCache" / "Roaming"
                    if local_cache_roaming.exists():
                        candidates.append(
                            (local_cache_roaming / "Claude", "Microsoft Store")
                        )

        # 2. Standard .exe installer → %APPDATA%\Claude
        if appdata:
            candidates.append((Path(appdata) / "Claude", "standard installer"))

        # 3. Alternate location seen on some systems → %LOCALAPPDATA%\Claude
        if local:
            candidates.append((Path(local) / "Claude", "local AppData"))

        # Return the first candidate whose parent already exists (most likely real),
        # falling back to the standard path so we always return something.
        for path, _ in candidates:
            if path.exists() or path.parent.exists():
                return path

        # Absolute fallback
        return Path(appdata or local or str(Path.home())) / "Claude"

    elif system == "Darwin":
        candidates = [
            Path.home() / "Library" / "Application Support" / "Claude",
        ]
        for path in candidates:
            if path.exists():
                return path
        return candidates[0]

    else:  # Linux and others
        candidates = [
            # Flatpak install
            Path.home() / ".var" / "app" / "com.anthropic.Claude" / "config" / "Claude",
            # Standard / direct install
            Path.home() / ".config" / "Claude",
        ]
        for path in candidates:
            if path.exists():
                return path
        return candidates[-1]


@app.command("setup-claude")
def setup_claude(
    workspace: Optional[str] = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Absolute path to the infobeans-rai project folder (default: current directory).",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Print the config that would be written without modifying anything.",
    ),
):
    """
    Register infobeans-rai as an MCP server in Claude Desktop.
    Alias for: infobeans-rai setup-mcp --target claude
    """
    ctx = typer.get_current_context()
    ctx.invoke(setup_mcp, target="claude", workspace=workspace, dry_run=dry_run)


@app.command("setup-mcp")
def setup_mcp(
    target: str = typer.Option(
        "claude",
        "--target",
        "-t",
        help="MCP client to configure: claude, copilot, gemini, or all.",
    ),
    workspace: Optional[str] = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Absolute path to the infobeans-rai project folder (default: current directory).",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Print the config that would be written without modifying anything.",
    ),
):
    """
    Register infobeans-rai as an MCP server in one or more AI clients.

    Supported targets:
      claude   — Claude Desktop (%APPDATA%\\Claude\\claude_desktop_config.json)
      copilot  — GitHub Copilot in VS Code (%APPDATA%\\Code\\User\\settings.json)
      gemini   — Gemini CLI (~/.gemini/settings.json)
      all      — All of the above
    """
    import platform

    targets = ["claude", "copilot", "gemini"] if target == "all" else [target.lower()]
    invalid = [t for t in targets if t not in ("claude", "copilot", "gemini")]
    if invalid:
        typer.echo(f"ERROR: Unknown target(s): {', '.join(invalid)}. Choose from: claude, copilot, gemini, all", err=True)
        raise typer.Exit(1)

    workspace_path = Path(workspace).resolve() if workspace else Path(os.getcwd()).resolve()

    # Validate workspace
    if not (workspace_path / "apps").exists():
        typer.echo(
            f"\n  WARNING: No 'apps' folder found at: {workspace_path}\n"
            "  This may be the wrong directory. Run from your project root or pass --workspace.\n",
            err=True,
        )
        if not typer.confirm("  Continue anyway?", default=False):
            raise typer.Exit(1)

    python_exe = Path(sys.executable).resolve()

    # Locate infobeans_rai_mcp.py
    mcp_script = Path(__file__).with_name("infobeans_rai_mcp.py").resolve()
    if not mcp_script.exists():
        try:
            import importlib.util
            spec = importlib.util.find_spec("infobeans_rai_mcp")
            if spec and spec.origin:
                mcp_script = Path(spec.origin).resolve()
        except Exception:
            pass
    if not mcp_script.exists():
        typer.echo(f"ERROR: infobeans_rai_mcp.py not found at {mcp_script}", err=True)
        raise typer.Exit(1)

    def _fwd(p: Path) -> str:
        return p.as_posix()

    system = platform.system()
    results = []

    # ── Claude Desktop ────────────────────────────────────────────────────────
    if "claude" in targets:
        server_block = {
            "command": _fwd(python_exe),
            "args": [_fwd(mcp_script)],
            "env": {"INFOBEANS_RAI_WORKSPACE": _fwd(workspace_path)},
        }
        if dry_run:
            typer.echo("\n[Claude Desktop] Config block that would be written:")
            typer.echo(json.dumps({"mcpServers": {"infobeans-rai": server_block}}, indent=2))
        else:
            # Close Claude if running
            try:
                import psutil
                import time
                try:
                    claude_procs = [
                        p for p in psutil.process_iter(["name", "pid"])
                        if (p.info.get("name") or "").lower() in ("claude.exe", "claude")
                    ]
                except Exception:
                    claude_procs = []
                if claude_procs:
                    typer.echo("\n  [Claude] Claude Desktop is running — closing it...")
                    close_it = typer.confirm("  Close Claude Desktop automatically now?", default=True)
                    if close_it:
                        try:
                            if system == "Windows":
                                result = subprocess.run(["taskkill", "/F", "/IM", "Claude.exe"], capture_output=True, text=True)
                            else:
                                result = subprocess.run(["pkill", "-x", "Claude"], capture_output=True, text=True)
                            if result.returncode == 0:
                                for _ in range(20):
                                    time.sleep(0.5)
                                    try:
                                        still = [
                                            p for p in psutil.process_iter(["name"])
                                            if (p.info.get("name") or "").lower() in ("claude.exe", "claude")
                                        ]
                                    except Exception:
                                        still = []
                                    if not still:
                                        break
                                typer.echo("  [Claude] Closed successfully.")
                            else:
                                raise RuntimeError(result.stderr.strip() or "Non-zero exit")
                        except Exception as e:
                            typer.echo(f"  [Claude] Could not close automatically: {e}", err=True)
                            if not typer.confirm("  Close it manually, then continue?", default=False):
                                raise typer.Exit(1)
                    else:
                        typer.echo("  [Claude] Please close Claude Desktop manually and re-run.", err=True)
                        raise typer.Exit(1)
            except ImportError:
                typer.echo("\n  [Claude] Make sure Claude Desktop is fully closed before continuing.")
                if not typer.confirm("  Is Claude Desktop closed?", default=True):
                    raise typer.Exit(1)

            config_dir = _find_claude_config_dir(system)
            config_file = config_dir / "claude_desktop_config.json"
            config_dir.mkdir(parents=True, exist_ok=True)
            existing = {}
            if config_file.exists():
                try:
                    with open(config_file, "r", encoding="utf-8") as f:
                        existing = json.load(f)
                except Exception as _parse_err:
                    typer.echo(
                        f"\n  ERROR: Could not parse existing config at {config_file}:\n"
                        f"    {_parse_err}\n"
                        "  Your existing Claude config was NOT modified.\n"
                        "  Fix the JSON file manually, then re-run this command.\n"
                        "  Or add the entry manually — use --dry-run to see the block.",
                        err=True,
                    )
                    raise typer.Exit(1)
            if config_file.exists():
                backup = config_file.with_suffix(".json.bak")
                import shutil as _shutil
                _shutil.copy2(config_file, backup)
                typer.echo(f"  [Claude] Backup created : {backup}")
            existing.setdefault("mcpServers", {})
            existing["mcpServers"]["infobeans-rai"] = server_block
            with open(config_file, "w", encoding="utf-8") as f:
                json.dump(existing, f, indent=2)
            results.append(("Claude Desktop", str(config_file)))
            typer.echo(f"\n  [Claude] Registered at: {config_file}")
            typer.echo(f"  [Claude] Install path : {config_dir}")
            typer.echo(f"  [Claude] Logs         : {config_dir / 'logs'}")
            typer.echo("  [Claude] Next step    : Fully reopen Claude Desktop → look for hammer (Tools) icon.")
            typer.echo("  [Claude] Verify first : Open the config file above and confirm 'infobeans-rai' entry exists before reopening.")

    # ── GitHub Copilot (VS Code) ──────────────────────────────────────────────
    if "copilot" in targets:
        server_block_copilot = {
            "type": "stdio",
            "command": _fwd(python_exe),
            "args": [_fwd(mcp_script)],
            "env": {"INFOBEANS_RAI_WORKSPACE": _fwd(workspace_path)},
        }
        if dry_run:
            typer.echo("\n[GitHub Copilot] Config block that would be written into settings.json:")
            typer.echo(json.dumps({"mcp": {"servers": {"infobeans-rai": server_block_copilot}}}, indent=2))
        else:
            if system == "Windows":
                appdata = os.environ.get("APPDATA", "")
                if not appdata:
                    typer.echo("  ERROR: APPDATA environment variable is not set — cannot locate VS Code settings.", err=True)
                    raise typer.Exit(1)
                vscode_settings = Path(appdata) / "Code" / "User" / "settings.json"
            elif system == "Darwin":
                vscode_settings = Path.home() / "Library" / "Application Support" / "Code" / "User" / "settings.json"
            else:
                vscode_settings = Path.home() / ".config" / "Code" / "User" / "settings.json"

            vscode_settings.parent.mkdir(parents=True, exist_ok=True)
            existing_vs = {}
            if vscode_settings.exists():
                try:
                    with open(vscode_settings, "r", encoding="utf-8") as f:
                        existing_vs = json.load(f)
                except Exception as _parse_err:
                    typer.echo(
                        f"\n  ERROR: Could not parse existing VS Code settings at {vscode_settings}:\n"
                        f"    {_parse_err}\n"
                        "  VS Code settings.json may contain comments (JSONC) which are not valid JSON.\n"
                        "  Your settings were NOT modified.\n"
                        "  Add the entry manually — use --dry-run to see the exact block to insert.\n"
                        "  Then save settings.json as standard JSON (strip comments) or use VS Code's\n"
                        "  built-in MCP settings UI under Copilot Chat → Tools.",
                        err=True,
                    )
                    raise typer.Exit(1)

            if vscode_settings.exists():
                backup_vs = vscode_settings.with_suffix(".json.bak")
                import shutil as _shutil
                _shutil.copy2(vscode_settings, backup_vs)
                typer.echo(f"  [Copilot] Backup created : {backup_vs}")
            existing_vs.setdefault("mcp", {}).setdefault("servers", {})
            existing_vs["mcp"]["servers"]["infobeans-rai"] = server_block_copilot
            with open(vscode_settings, "w", encoding="utf-8") as f:
                json.dump(existing_vs, f, indent=2)
            results.append(("GitHub Copilot", str(vscode_settings)))
            typer.echo(f"\n  [Copilot] Registered at: {vscode_settings}")
            typer.echo("  [Copilot] Next step    : No restart needed — open Copilot Chat in VS Code (Ctrl+Alt+I),")
            typer.echo("                           click the tools icon, and enable 'infobeans-rai'.")

    # ── Gemini CLI ────────────────────────────────────────────────────────────
    if "gemini" in targets:
        server_block_gemini = {
            "command": _fwd(python_exe),
            "args": [_fwd(mcp_script)],
            "env": {"INFOBEANS_RAI_WORKSPACE": _fwd(workspace_path)},
        }
        if dry_run:
            typer.echo("\n[Gemini CLI] Config block that would be written:")
            typer.echo(json.dumps({"mcpServers": {"infobeans-rai": server_block_gemini}}, indent=2))
        else:
            if system == "Windows":
                gemini_dir = Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".gemini"
            else:
                gemini_dir = Path.home() / ".gemini"

            gemini_settings = gemini_dir / "settings.json"
            gemini_dir.mkdir(parents=True, exist_ok=True)
            existing_gem = {}
            if gemini_settings.exists():
                try:
                    with open(gemini_settings, "r", encoding="utf-8") as f:
                        existing_gem = json.load(f)
                except Exception as _parse_err:
                    typer.echo(
                        f"\n  ERROR: Could not parse existing Gemini settings at {gemini_settings}:\n"
                        f"    {_parse_err}\n"
                        "  Your settings were NOT modified.\n"
                        "  Fix the JSON file manually, then re-run this command.\n"
                        "  Or add the entry manually — use --dry-run to see the block.",
                        err=True,
                    )
                    raise typer.Exit(1)

            if gemini_settings.exists():
                backup_gem = gemini_settings.with_suffix(".json.bak")
                import shutil as _shutil
                _shutil.copy2(gemini_settings, backup_gem)
                typer.echo(f"  [Gemini] Backup created : {backup_gem}")
            existing_gem.setdefault("mcpServers", {})
            existing_gem["mcpServers"]["infobeans-rai"] = server_block_gemini
            with open(gemini_settings, "w", encoding="utf-8") as f:
                json.dump(existing_gem, f, indent=2)
            results.append(("Gemini CLI", str(gemini_settings)))
            typer.echo(f"\n  [Gemini] Registered at: {gemini_settings}")
            typer.echo("  [Gemini] Next step    : No restart needed — activate venv, then run:")
            typer.echo('                          gemini "run tests for app myapp"')

    if not dry_run and results:
        typer.echo("\n  ── Summary ─────────────────────────────────────────────")
        for client, path in results:
            typer.echo(f"  {client:<20} {path}")
        typer.echo("")
        typer.echo(f"  Python   : {_fwd(python_exe)}")
        typer.echo(f"  Script   : {_fwd(mcp_script)}")
        typer.echo(f"  Workspace: {_fwd(workspace_path)}")
        typer.echo("")
        typer.echo("  Tip: run with --dry-run to preview config without writing.")
        typer.echo("")


@app.command("run-tests", hidden=True)
def run_tests(
    folder_name: str = typer.Argument(
        ...,
        help="Name of the folder inside 'apps/' containing test cases.",
    ),
):
    """
    Run pytest for a specific application folder inside apps/.

    Example:
      python infobeans_rai.py run-tests my-tests
    """
    repo_root = os.getcwd()
    apps_dir = os.path.join(repo_root, "apps")
    target_dir = os.path.join(apps_dir, folder_name)

    # --- Validation ---
    if not os.path.isdir(target_dir):
        logger.error(
            f"Specified folder does not exist inside apps directory: apps/{folder_name}"
        )
        raise typer.Exit(1)

    # Check for pytest-compatible test files
    test_files = glob.glob(os.path.join(target_dir, "test_*.py")) + glob.glob(
        os.path.join(target_dir, "*_test.py")
    )
    if not test_files:
        logger.error(f"No pytest test cases found in: apps/{folder_name}")
        raise typer.Exit(1)

    logger.info(
        f"Running pytest for apps/{folder_name} ({len(test_files)} test file(s) found)"
    )

    try:
        result = subprocess.run(
            [sys.executable, "-m", "pytest", "-s", target_dir], cwd=repo_root
        )
        sys.exit(result.returncode)
    except Exception as e:
        logger.error(f"Failed to run pytest: {e}")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
