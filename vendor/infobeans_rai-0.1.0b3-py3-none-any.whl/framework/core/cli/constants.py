# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

from framework.plugins.allure.allure_plugin import AllurePlugin
from framework.plugins.html_report.html_report_plugin import HtmlReportPlugin
from framework.plugins.jira.jira_xray_plugin import XrayPlugin

PLUGIN_CLASS_MAP = {
    "HtmlReportPlugin": HtmlReportPlugin,
    "AllurePlugin": AllurePlugin,
    "XrayPlugin": XrayPlugin,
}

REPORTS_DIR_NAME = "reports"

TYPER_CONTEXT_SETTINGS = dict(help_option_names=["-h", "--help"])
