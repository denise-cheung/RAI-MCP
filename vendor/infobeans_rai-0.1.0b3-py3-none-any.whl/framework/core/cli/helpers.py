# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import json
import os
import shutil
import subprocess
import sys
from typing import List

from framework.core.cli.constants import PLUGIN_CLASS_MAP
from framework.core.utils import get_logger

logger = get_logger()


def load_plugins(reporting_config, full_config):
    plugins = []

    for plugin_entry in reporting_config:
        if plugin_entry.get("enabled"):
            plugin_name = plugin_entry["name"]
            plugin_cls = PLUGIN_CLASS_MAP.get(plugin_name)
            if plugin_cls:
                plugins.append(plugin_cls(full_config))

    return plugins


def parse_raw_json_report_dict(raw_json: dict) -> dict:
    """Parse raw JSON report dictionary and return test results with evidence info."""
    nodeid = raw_json.get("nodeid", "")
    outcome = raw_json.get("outcome") or raw_json.get("status") or "failed"
    trace_call = raw_json.get("call", {})
    longrepr = raw_json.get("longrepr") or trace_call.get("longrepr", "")
    error_message = trace_call.get("crash", {}).get("message", "")
    test_name = None
    if nodeid:
        test_name = nodeid.split("::")[-1].split("[")[0]  # Extract test function name
    
    # Extract duration from root or sum of stages
    duration = raw_json.get("duration")
    if duration is None or duration == 0:
        duration = 0
        for stage in ["setup", "call", "teardown"]:
            duration += raw_json.get(stage, {}).get("duration", 0)
    
    # If still None/missing, default to 0
    duration = float(duration or 0)

    # Prefer xray marker from user_properties when present
    xray_key = None
    user_props = raw_json.get("user_properties") or []
    # user_properties may be list of pairs or list of dicts
    for prop in user_props:
        try:
            if isinstance(prop, (list, tuple)) and len(prop) >= 2:
                name, val = prop[0], prop[1]
                if name == "xray":
                    xray_key = str(val)
            elif isinstance(prop, dict):
                xray_key = prop.get("xray")
            else:
                continue
        except Exception:
            continue
    # normalize longrepr to string
    if isinstance(longrepr, (dict, list)):
        try:
            longrepr = json.dumps(longrepr)
        except Exception:
            longrepr = str(longrepr)
    else:
        longrepr = str(longrepr)
    test_key = xray_key if xray_key else nodeid

    test_result = {
        "key": test_key,
        "status": outcome,
        "error": longrepr,
        "test_name": test_name,
        "error_message": error_message,
        "nodeid": nodeid,
        "duration": duration,
    }

    # Collect evidence metadata
    evidence_metadata = []

    # Add traceback as evidence reference
    if longrepr:
        evidence_metadata.append(
            {
                "type": "traceback",
                "size": len(longrepr.encode("utf-8")),
                "name": f"{test_key}_traceback.txt",
            }
        )

    # Add user attachments if present
    if raw_json.get("attachments"):
        for attachment in raw_json.get("attachments", []):
            evidence_metadata.append(
                {
                    "type": attachment.get("type", "attachment"),
                    "name": attachment.get("name", "attachment"),
                    "size": (
                        len(attachment.get("content", b""))
                        if isinstance(attachment.get("content"), bytes)
                        else 0
                    ),
                }
            )

    if evidence_metadata:
        test_result["evidence_metadata"] = evidence_metadata

    return test_result


def compute_test_summary(tests: List[dict], wall_clock: float) -> dict:
    """Compute summary statistics from a list of (deduplicated) tests."""
    total = len(tests)
    passed_only = sum(1 for t in tests if t.get("status") == "passed")
    failed = sum(1 for t in tests if t.get("status") == "failed")
    skipped = sum(1 for t in tests if t.get("status") == "skipped")
    error = sum(1 for t in tests if t.get("status") == "error")
    rerun = sum(1 for t in tests if t.get("status") == "rerun")
    total_effort = sum(t.get("duration", 0) for t in tests)
    
    # Per user request, passed count should include rerun test cases that eventually passed
    passed = passed_only + rerun
    
    return {
        "total": total,
        "passed": passed,
        "failed": failed + error,
        "skipped": skipped,
        "error": 0,
        "rerun": rerun,
        "num_tests": total,
        "duration": wall_clock,
        "total_effort": total_effort
    }


def save_json_report(out_file: str, tests: List[dict], summary: dict, wall_clock: float, created: str):
    """Save the merged/corrected report to a JSON file."""
    merged = {
        "tests": tests,
        "summary": summary,
        "duration": wall_clock,
        "created": created
    }
    if os.path.dirname(out_file):
        os.makedirs(os.path.dirname(out_file), exist_ok=True)
    with open(out_file, "w", encoding="utf-8") as outfh:
        json.dump(merged, outfh, indent=2)


def merge_json_reports(app_name: str, json_files: List[str], out_file: str) -> dict:
    all_tests = []
    created_timestamps = []
    
    # Track wall-clock duration from batch roots (Execution Duration)
    wall_clock_duration = 0

    for jf in json_files:
        if not os.path.exists(jf):
            continue
        try:
            with open(jf, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            for test in data.get("tests", []):
                # Batch JSON files are already processed by get_test_summary_from_json_report
                # (they have 'key', 'status', 'nodeid' etc.) — use them directly to preserve
                # the Xray test key. Re-parsing would lose it since user_properties is stripped.
                all_tests.append(test)
            
            # Collect created timestamps
            if "created" in data:
                created_timestamps.append(data["created"])
            
            wall_clock_duration += data.get("duration", 0)
        except Exception:
            continue

    # deduplicate by nodeid, keeping the last seen result (crucial for reruns)
    distinct_tests = {}
    for t in all_tests:
        distinct_tests[t["nodeid"]] = t
    
    merged_tests = list(distinct_tests.values())
    
    # compute summary using shared helper
    summary = compute_test_summary(merged_tests, wall_clock_duration)
    
    # Determine the earliest created timestamp
    earliest_created = ""
    if created_timestamps:
        try:
            # Assumes created values are numeric strings (Unix timestamps) as seen in tests
            earliest_created = str(min(float(ts) for ts in created_timestamps))
        except (ValueError, TypeError):
            earliest_created = min(created_timestamps)

    # Save using shared helper
    save_json_report(out_file, merged_tests, summary, wall_clock_duration, earliest_created)

    return {
        "app_name": app_name,
        "total": summary["total"],
        "passed": summary["passed"],
        "failed": summary["failed"],
        "skipped": summary["skipped"],
        "duration": wall_clock_duration,
        "tests": merged_tests,
    }


def is_allure_enabled(reporting_config) -> bool:
    for plugin_entry in reporting_config:
        if plugin_entry.get("name") == "AllurePlugin":
            return plugin_entry.get("enabled", False)
    return False


def generate_allure_report_files(
    allure_path: str, single_file: bool = False, output_dir: str = ""
):
    """Generate Allure report from results directory."""
    if not output_dir:
        output_dir = os.path.normpath(os.path.join(allure_path, "..", "allure-report"))

    # To enable Trends in Allure, we must preserve history from previous report
    history_dir = os.path.join(output_dir, "history")
    if os.path.exists(history_dir):
        dest_history_dir = os.path.join(allure_path, "history")
        try:
            # Ensure results directory exists
            os.makedirs(allure_path, exist_ok=True)
            if os.path.exists(dest_history_dir):
                shutil.rmtree(dest_history_dir)
            shutil.copytree(history_dir, dest_history_dir)
            logger.debug(
                f"Preserving history for Trends: copied {history_dir} to {dest_history_dir}"
            )
        except Exception as e:
            logger.debug(f"Could not preserve Allure history: {e}")
    allure_bin = shutil.which("allure") or "allure"
    try:
        subprocess.run(
            [allure_bin, "generate", allure_path, "-o", output_dir, "--clean"]
            + (["--single-file"] if single_file else []),
            check=True,
            stdout=sys.stderr,
        )
    except subprocess.CalledProcessError as e:
        logger.error(f"Error generating Allure report.")
        logger.debug(f"Reason: {e}")
    except Exception as e:
        logger.error(f"Unknown exception while generating Allure report.")
        logger.debug(f"Reason: {e}")
