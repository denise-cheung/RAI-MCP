# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import json
import os
from typing import List

logger_message = "[cli.reports]"


def render_simple_html(
    app_path: str, summary: dict, batch_files: List[str] = None
) -> str:
    reports_dir = os.path.join(app_path, "reports")
    os.makedirs(reports_dir, exist_ok=True)
    out_html = os.path.join(reports_dir, "report.html")
    total = summary.get("total", 0)
    passed = summary.get("passed", 0)
    failed = summary.get("failed", 0)
    lines = [
        "<html>",
        "<head><title>Test Report</title></head>",
        "<body>",
        f"<h1>Test Report for {os.path.basename(app_path)}</h1>",
        f"<p>Total: {total} — Passed: {passed} — Failed: {failed}</p>",
    ]
    if batch_files:
        lines.append("<h2>Batch Reports</h2>")
        lines.append("<ul>")
        for bf in batch_files:
            fn = os.path.basename(bf)
            lines.append(f'<li><a href="{fn}">{fn}</a></li>')
        lines.append("</ul>")
    lines.extend(["</body>", "</html>"])
    with open(out_html, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))
    return out_html


def load_json_report(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {}
