# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import os
import re
from typing import Any, TextIO

import yaml


def parse_yaml_content(file_obj: TextIO) -> dict:
    """
    Parse YAML content from a file object and resolve environment variables in template strings.

    Args:
        file_obj (TextIO): The file object containing YAML content to parse.

    Returns:
        dict: The parsed YAML content as a dictionary with environment variables resolved.
    """
    # Load the YAML content from the file object
    data = yaml.safe_load(file_obj)

    # Recursively resolve environment variables in the YAML data
    def resolve_env_vars(value: Any) -> Any:
        if isinstance(value, dict):
            return {k: resolve_env_vars(v) for k, v in value.items()}
        elif isinstance(value, list):
            return [resolve_env_vars(v) for v in value]
        elif isinstance(value, str):
            # Check for environment variable pattern
            pattern = r"\$\{([^}]+)\}"
            matches = re.findall(pattern, value)
            if matches:
                for match in matches:
                    env_value = os.getenv(match)
                    if env_value is not None:
                        value = value.replace(f"${{{match}}}", env_value)
            return value
        else:
            return value

    # Resolve environment variables in the loaded YAML data
    resolved_data = resolve_env_vars(data)

    # Return the resolved data as a dictionary
    return resolved_data
