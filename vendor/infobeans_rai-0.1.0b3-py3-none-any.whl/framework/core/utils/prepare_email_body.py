# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

#!/usr/bin/env python3
"""
Script to prepare email HTML body by replacing placeholders with actual values from GitHub Actions.
"""
import os
from pathlib import Path

# Detect the CI environment
IS_AZURE = "SYSTEM_TEAMFOUNDATIONCOLLECTIONURI" in os.environ
IS_GITHUB = "GITHUB_ACTIONS" in os.environ


def calculate_percentages(total, passed, failed, skipped):
    """Calculate percentage values for test results."""
    if total == 0:
        return "0", "0", "0", "0"

    passed_percent = round((passed / total) * 100, 1)
    failed_percent = round((failed / total) * 100, 1)
    skipped_percent = round((skipped / total) * 100, 1)

    return (
        str(passed_percent),
        str(failed_percent),
        str(skipped_percent),
        str(passed_percent),
    )


def replace_placeholders(template_path, output_path, replacements):
    """Replace placeholders in the template with actual values."""
    with open(template_path, "r", encoding="utf-8") as f:
        content = f.read()

    for placeholder, value in replacements.items():
        content = content.replace(f"{{{{{placeholder}}}}}", str(value))

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"Email body prepared and saved to {output_path}")


def safe_int(value, default=0):
    """Safely convert a value to int, handling empty strings and None."""
    if not value or value.strip() == "":
        return default
    try:
        return int(value)
    except (ValueError, TypeError):
        return default


def get_xray_element_tag(xray_status, xray_execution_id, xray_execution_url):
    if xray_status == "Uploaded":
        return f"""
        <tr style='background:#F9F9F9;'>
          <td style='padding:8px 12px; font-weight:bold; color:#666;'>Xray Execution Details:</td>
          <td style='padding:8px 12px;'>
            <a href='{xray_execution_url}'
               style='color:#0056b3; text-decoration:none; font-weight:bold;'>🔗 {xray_execution_id}</a>
          </td>
        </tr>
        """
    else:
        return ""


def render_email_template(template_path: Path) -> Path:
    """
    Generate email body HTML using the given template.
    Output file is created in the SAME directory as the template.
    """
    if not template_path.exists():
        raise FileNotFoundError(f"Template file not found: {template_path}")
    github_actor = ""
    test_result = ""
    github_ref = ""
    github_repository = ""
    pipeline_name = ""
    run_number = ""
    run_id = ""
    project = ""
    build_url_link_text = ""
    collection_uri = ""
    build_url_link = ""
    xray_status = ""
    xray_execution_id = ""
    xray_execution_url = ""
    app_name = ""

    # Construct build URL
    if IS_AZURE:
        github_actor = (os.environ.get("BUILD_REQUESTEDFOR", "Azure DevOps"),)
        # test_result = "success" if os.environ.get("AGENT_JOBSTATUS", "").lower() == "succeeded" else "failure"
        github_ref = os.environ.get("BUILD_SOURCEBRANCHNAME", "Unknown")
        total_tests = safe_int(os.environ.get("TOTAL_TESTS", "0"))
        passed_tests = safe_int(os.environ.get("PASSED_TESTS", "0"))
        failed_tests = safe_int(os.environ.get("FAILED_TESTS", "0"))
        skipped_tests = safe_int(os.environ.get("SKIPPED_TESTS", "0"))

        github_repository = os.environ.get("BUILD_REPOSITORY_NAME", "Unknown")
        pipeline_name = os.environ.get("BUILD_DEFINITIONNAME", "Unknown")
        run_number = os.environ.get("BUILD_BUILDNUMBER", "Unknown")
        run_id = os.environ.get("BUILD_BUILDID", "Unknown")
        # server_url = os.environ.get("SYSTEM_TEAMFOUNDATIONCOLLECTIONURI", "Unknown")
        project = os.environ.get("SYSTEM_TEAMPROJECT", "Unknown")
        collection_uri = os.environ.get("SYSTEM_COLLECTIONURI")
        build_url_link = (
            f"{collection_uri}{project}/_build/results?buildId={run_id}&view=results"
        )
        build_url_link_text = "Azure Pipeline Run"
        xray_status = os.environ.get("XRAY_STATUS", "Unknown")
        xray_execution_id = os.environ.get("XRAY_EXECUTION_ID", "Unknown")
        xray_execution_url = os.environ.get("XRAY_EXECUTION_URL", "Unknown")
        app_name = os.environ.get("APP_NAME", "Unknown")

    elif IS_GITHUB:
        # Get values from environment variables
        github_actor = os.environ.get("GITHUB_ACTOR", "Unknown")
        github_ref = os.environ.get("GITHUB_REF", "Unknown")
        total_tests = safe_int(os.environ.get("TOTAL_TESTS", "0"))
        passed_tests = safe_int(os.environ.get("PASSED_TESTS", "0"))
        failed_tests = safe_int(os.environ.get("FAILED_TESTS", "0"))
        skipped_tests = safe_int(os.environ.get("SKIPPED_TESTS", "0"))
        github_repository = os.environ.get("GITHUB_REPOSITORY", "Unknown")
        pipeline_name = os.environ.get("GITHUB_WORKFLOW", "Unknown")
        run_number = os.environ.get("GITHUB_RUN_NUMBER", "Unknown")
        run_id = os.environ.get("GITHUB_RUN_ID", "Unknown")
        github_server_url = os.environ.get("GITHUB_SERVER_URL", "https://github.com")
        build_url_link = (
            f"{github_server_url}/{github_repository}/actions/runs/{run_id}"
        )
        build_url_link_text = "GitHub Actions Run"
        # TO DO to be updated once the github action pipeline is developed to extract the xray execution details
        xray_status = os.environ.get("XRAY_STATUS", "unknown")
        xray_execution_id = os.environ.get("XRAY_EXECUTION_ID", "unknown")
        xray_execution_url = os.environ.get("XRAY_EXECUTION_URL", "unknown")
        app_name = os.environ.get("APP_NAME", "Unknown")

    test_result = os.environ.get("TEST_RESULT", "Unknown")

    # Calculate percentages
    passed_percent, failed_percent, skipped_percent, success_rate = (
        calculate_percentages(total_tests, passed_tests, failed_tests, skipped_tests)
    )
    xray_element_replacement = get_xray_element_tag(
        xray_status, xray_execution_id, xray_execution_url
    )
    # Prepare replacements dictionary
    replacements = {
        "GITHUB_ACTOR": github_actor,
        "TEST_RESULT": test_result,
        "GITHUB_REF": github_ref,
        "TOTAL_TESTS": total_tests,
        "PASSED_TESTS": passed_tests,
        "FAILED_TESTS": failed_tests,
        "SKIPPED_TESTS": skipped_tests,
        "PASSED_PERCENT": passed_percent,
        "FAILED_PERCENT": failed_percent,
        "SKIPPED_PERCENT": skipped_percent,
        "SUCCESS_RATE": success_rate,
        "GITHUB_REPOSITORY": github_repository,
        "GITHUB_WORKFLOW": pipeline_name,
        "GITHUB_RUN_NUMBER": run_number,
        "GITHUB_RUN_ID": run_id,
        "BUILD_URL_LINK": build_url_link,
        "BUILD_URL_LINK_TEXT": build_url_link_text,
        "XRAY_ELEMENT_REPLACEMENT": xray_element_replacement,
        "APP_NAME": app_name,
    }

    output_path = template_path.parent / "email-body.html"
    replace_placeholders(template_path, output_path, replacements)
    return output_path
