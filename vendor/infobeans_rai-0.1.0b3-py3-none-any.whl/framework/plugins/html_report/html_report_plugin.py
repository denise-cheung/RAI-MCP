# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import os
from pathlib import Path

from framework.plugins.base import Plugin


class HtmlReportPlugin(Plugin):
    def __init__(self, config):
        self.config = config

    def is_enabled(self) -> bool:
        reporting = self.config.get("reporting", [])
        for entry in reporting:
            if entry.get("name") == "HtmlReportPlugin":
                return entry.get("enabled", False)
        return False

    def on_session_start(self, context: dict):
        pass

    def on_session_finish(self, context: dict):
        app_path = context.get("app_path")
        summary = context["summary"]
        output = Path(os.path.join(app_path, "reports", "html"))
        output.mkdir(parents=True, exist_ok=True)

        report_path = Path(os.path.join(output, "index.html"))
        report_path.write_text(self._render(summary), encoding="utf-8")

    def _render(self, summary: dict) -> str:
        tests = summary.get("tests", [])
        duration = summary.get("duration", 0)
        skipped = summary.get("skipped", 0)

        def fmt_duration(secs):
            secs = float(secs or 0)
            if secs < 60:
                return f"{secs:.4f}s"
            m, s = divmod(secs, 60)
            return f"{int(m)}m {round(s)}s"

        rows = []
        for i, t in enumerate(tests):
            status = t.get("status", "unknown")
            status_class = {"passed": "pass", "failed": "fail", "skipped": "skip", "error": "fail"}.get(status, "skip")
            test_name = t.get("test_name") or t.get("nodeid", "")
            nodeid = t.get("nodeid", "")
            dur = fmt_duration(t.get("duration", 0))
            error_msg = t.get("error_message", "") or ""
            longrepr = t.get("error", "") or ""

            detail_id = f"detail-{i}"
            toggle = ""
            if longrepr and longrepr.strip() and longrepr.strip() != "None":
                escaped = longrepr.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                toggle = (
                    f'<br><a href="javascript:void(0)" onclick="toggle(\'{detail_id}\')" class="toggle-link">show traceback</a>'
                    f'<pre id="{detail_id}" class="traceback" style="display:none">{escaped}</pre>'
                )

            err_cell = f'<span class="err-msg">{error_msg}</span>{toggle}' if error_msg or toggle else ""

            rows.append(f"""
      <tr>
        <td class="num">{i + 1}</td>
        <td class="nodeid" title="{nodeid}">{test_name}</td>
        <td><span class="badge {status_class}">{status.upper()}</span></td>
        <td class="dur">{dur}</td>
        <td class="err">{err_cell}</td>
      </tr>""")

        rows_html = "".join(rows)

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <title>Automation Report – {summary['app_name']}</title>
  <style>
    *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ font-family: Arial, sans-serif; background: #f4f6f9; color: #333; padding: 24px; }}
    h1 {{ font-size: 1.5rem; margin-bottom: 16px; }}
    .summary-bar {{ display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 24px; }}
    .stat {{ background: #fff; border-radius: 8px; padding: 12px 20px; text-align: center;
             box-shadow: 0 1px 4px rgba(0,0,0,.1); min-width: 90px; }}
    .stat .val {{ font-size: 1.8rem; font-weight: bold; }}
    .stat .lbl {{ font-size: .75rem; color: #666; text-transform: uppercase; letter-spacing: .05em; }}
    .stat.total .val {{ color: #333; }}
    .stat.pass  .val {{ color: #22863a; }}
    .stat.fail  .val {{ color: #cb2431; }}
    .stat.skip  .val {{ color: #b08800; }}
    table {{ width: 100%; border-collapse: collapse; background: #fff;
             border-radius: 8px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,.1); }}
    thead th {{ background: #2d3748; color: #fff; padding: 10px 12px; text-align: left;
                font-size: .8rem; text-transform: uppercase; letter-spacing: .05em; }}
    tbody tr:nth-child(even) {{ background: #f8f9fb; }}
    tbody tr:hover {{ background: #eef2ff; }}
    td {{ padding: 8px 12px; font-size: .85rem; vertical-align: top; border-bottom: 1px solid #e8ecf0; }}
    td.num {{ color: #999; width: 40px; text-align: right; }}
    td.nodeid {{ max-width: 340px; word-break: break-word; font-family: monospace; font-size: .8rem; }}
    td.dur {{ white-space: nowrap; color: #555; width: 70px; }}
    td.err {{ max-width: 400px; word-break: break-word; }}
    .badge {{ display: inline-block; padding: 2px 8px; border-radius: 4px;
              font-size: .75rem; font-weight: bold; letter-spacing: .05em; }}
    .badge.pass {{ background: #d4edda; color: #155724; }}
    .badge.fail {{ background: #f8d7da; color: #721c24; }}
    .badge.skip {{ background: #fff3cd; color: #856404; }}
    .err-msg {{ color: #cb2431; font-size: .8rem; }}
    .toggle-link {{ font-size: .75rem; color: #0366d6; cursor: pointer; }}
    pre.traceback {{ margin-top: 6px; padding: 8px; background: #f6f8fa; border: 1px solid #ddd;
                     border-radius: 4px; font-size: .72rem; white-space: pre-wrap; word-break: break-all;
                     max-height: 300px; overflow-y: auto; }}
    .filters {{ margin-bottom: 12px; display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }}
    .filters label {{ font-size: .8rem; color: #555; }}
    .filters select, .filters input {{ padding: 5px 8px; border: 1px solid #ccc;
                                        border-radius: 4px; font-size: .8rem; }}
    .meta {{ font-size: .78rem; color: #666; margin-bottom: 16px; }}
  </style>
</head>
<body>
  <h1>Automation Report – {summary['app_name']}</h1>
  <p class="meta">Total duration: {fmt_duration(duration)}</p>

  <div class="summary-bar">
    <div class="stat total"><div class="val">{summary['total']}</div><div class="lbl">Total</div></div>
    <div class="stat pass"> <div class="val">{summary['passed']}</div><div class="lbl">Passed</div></div>
    <div class="stat fail"> <div class="val">{summary['failed']}</div><div class="lbl">Failed</div></div>
    <div class="stat skip"> <div class="val">{skipped}</div><div class="lbl">Skipped</div></div>
  </div>

  <div class="filters">
    <label>Filter by status:</label>
    <select id="statusFilter" onchange="filterTable()">
      <option value="">All</option>
      <option value="PASSED">Passed</option>
      <option value="FAILED">Failed</option>
      <option value="SKIPPED">Skipped</option>
    </select>
    <label>Search:</label>
    <input id="searchInput" type="text" placeholder="test name…" oninput="filterTable()"/>
  </div>

  <table id="resultsTable">
    <thead>
      <tr>
        <th>#</th>
        <th>Test</th>
        <th>Status</th>
        <th>Duration</th>
        <th>Error</th>
      </tr>
    </thead>
    <tbody>
      {rows_html}
    </tbody>
  </table>

  <script>
    function toggle(id) {{
      var el = document.getElementById(id);
      var link = el.previousSibling;
      if (el.style.display === 'none') {{
        el.style.display = 'block';
        link.textContent = 'hide traceback';
      }} else {{
        el.style.display = 'none';
        link.textContent = 'show traceback';
      }}
    }}
    function filterTable() {{
      var status = document.getElementById('statusFilter').value.toLowerCase();
      var search = document.getElementById('searchInput').value.toLowerCase();
      var rows = document.querySelectorAll('#resultsTable tbody tr');
      rows.forEach(function(row) {{
        var badge = row.querySelector('.badge');
        var badgeText = badge ? badge.textContent.toLowerCase() : '';
        var nodeid = row.cells[1] ? row.cells[1].textContent.toLowerCase() : '';
        var statusMatch = !status || badgeText === status;
        var searchMatch = !search || nodeid.includes(search);
        row.style.display = (statusMatch && searchMatch) ? '' : 'none';
      }});
    }}
  </script>
</body>
</html>"""
