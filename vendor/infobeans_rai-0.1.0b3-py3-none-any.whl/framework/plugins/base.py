# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

from abc import ABC, abstractmethod


class Plugin(ABC):
    """
    INTERNAL CONTRACT
    All plugins must implement these hooks.
    """

    @abstractmethod
    def is_enabled(self) -> bool:
        pass

    @abstractmethod
    def on_session_start(self, context: dict):
        pass

    @abstractmethod
    def on_session_finish(self, context: dict):
        pass
