# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only

import os
from .constants import OUT_DIR


def ensure_dir():
    os.makedirs(f"{OUT_DIR}/validation", exist_ok=True)