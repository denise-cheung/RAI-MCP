# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only


from common.constants import COPYRIGHT_BLOCK, OUT_DIR


def generate_validation_engine():

    with open(f"{OUT_DIR}/validation/__init__.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """
            """
        )


    with open(f"{OUT_DIR}/validation/config.yaml", "w") as f:
        f.write(
            """
version: v1

rules:
  status_code:
    enabled: true
    allowed_ranges: [200, 400]

  response_time:
    enabled: true
    max_ms: 3500

  headers:
    enabled: true
    required:
      - Content-Type

  empty_response:
    enabled: true

  json_schema:
    enabled: false
"""
        )

    #Custom validation rules YAML

    with open(f"{OUT_DIR}/validation/custom_rules.yaml", "w") as f:
        f.write(
            """
version: v1

custom_rules:
  - id: USER_ID_PRESENT
    type: equality
    jsonpath: "$.post.id"
    expected: 100
    negate: true
    message: "User ID must be present"

  - id: EMAIL_FORMAT
    type: regex
    jsonpath: "$.email"
    pattern: '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$'
    message: "Invalid email format"

  - id: AGE_RANGE
    type: range
    jsonpath: "$.age"
    min: 18
    max: 60
    message: "Age must be between 18 and 60"

  - id: STATUS_DEPENDENT_RULE
    type: conditional
    if:
      jsonpath: "$.status"
      equals: "ACTIVE"
    then:
      jsonpath: "$.deactivated_at"
      equals: null
    message: "Active users must not have deactivated_at"

  - id: AUTHOR_NAME_NO_NUMBERS
    type: regex
    jsonpath: "$.author.name"
    pattern: '^[^0-9]+$'
    message: "Author name must not contain numbers"

  - id: PAGE_RANGE
    type: range
    jsonpath: "$[*].num_pages"
    min: 1
    max: 900
    message: "Age must be between 1 and 60"

"""
        )

    # Rule result 
    with open(f"{OUT_DIR}/validation/rule_result.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """

class RuleResult:
    def __init__(self, rule_id, passed, reason=None, actual_value=None, expected_value=None):
        self.rule_id = rule_id
        self.passed = passed
        self.reason = reason
        self.actual_value = actual_value
        self.expected_value = expected_value

    def __repr__(self):
        if self.reason and self.reason.startswith("SKIPPED"):
            return f"[SKIPPED] {self.rule_id}"
        status = "PASS" if self.passed else "FAIL"
        msg = f"[{status}] {self.rule_id}: {self.reason or ''}"
        if not self.passed and self.actual_value is not None:
            msg += f" (actual: {self.actual_value}"
            if self.expected_value is not None:
                msg += f", expected: {self.expected_value}"
            msg += ")"
        return msg

"""
        )

    # Custom rules engine

    with open(f"{OUT_DIR}/validation/custom_rule_engine.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """



import re
import yaml
from jsonpath_ng import parse
from .rule_result import RuleResult


class CustomRuleEngine:
    def __init__(self, rule_file):
        with open(rule_file) as f:
            self.rules = yaml.safe_load(f)["custom_rules"]

    def _extract_all(self, body, jsonpath):
        if body is None or not jsonpath:
            return []

        try:
            expr = parse(jsonpath)
            matches = expr.find(body)
            return [match.value for match in matches]
        except Exception:
            # Invalid JSONPath or evaluation error
            return []

    def _normalize_value(self, value):
        
        if isinstance(value, list):
            return value[0] if value else None
        return value

    def validate(self, response):
        results = []
        body = response.json()

        for rule in self.rules:
            rule_id = rule["id"]
            rule_type = rule["type"]
            jsonpath = rule.get("jsonpath")

            try:
                values = self._extract_all(body, jsonpath)

                # RULE APPLICABILITY CHECK
                if not values:
                    results.append(
                        RuleResult(rule_id, True, "SKIPPED: field not present")
                    )
                    continue

                passed = True
                failed_actual = None
                failed_expected = None

                for actual in values:
                    actual = self._normalize_value(actual)

                    # If value cannot be normalized, fail rule
                    if actual is None:
                        passed = False
                        failed_actual = actual
                        break

                    if rule_type == "equality":
                        expected = rule["expected"]
                        result = (actual == expected)
                        if rule.get("negate"):
                            result = not result
                        if not result:
                            failed_actual = actual
                            failed_expected = expected

                    elif rule_type == "regex":
                        result = bool(re.match(rule["pattern"], str(actual)))
                        if not result:
                            failed_actual = actual
                            failed_expected = rule["pattern"]

                    elif rule_type == "range":
                        if not isinstance(actual, (int, float)):
                            result = False
                            failed_actual = actual
                            failed_expected = f"[{rule['min']}, {rule['max']}]"
                        else:
                            result = rule["min"] <= actual <= rule["max"]
                            if not result:
                                failed_actual = actual
                                failed_expected = f"[{rule['min']}, {rule['max']}]"

                    elif rule_type == "conditional":
                        condition = rule.get("if")
                        then = rule.get("then")

                        # Invalid rule definition  PASS
                        if not condition or not then:
                            result = True

                        else:
                            if_values = self._extract_all(
                                body, condition.get("jsonpath")
                            )
                            if_values = [
                                self._normalize_value(v) for v in if_values
                            ]

                            # IF field missing  SKIP
                            if not if_values:
                                result = True

                            # IF condition matched
                            elif condition.get("equals") in if_values:
                                then_values = self._extract_all(
                                    body, then.get("jsonpath")
                                )
                                then_values = [
                                    self._normalize_value(v) for v in then_values
                                ]

                                # THEN field missing  FAIL
                                if not then_values:
                                    result = False
                                else:
                                    result = then.get("equals") in then_values

                            # IF condition not met  PASS
                            else:
                                result = True
                    else:
                        raise ValueError(f"Unknown rule type: {rule_type}")

                    if not result:
                        passed = False
                        break

                results.append(
                    RuleResult(
                        rule_id,
                        passed,
                        None if passed else rule["message"],
                        actual_value=failed_actual if not passed else None,
                        expected_value=failed_expected if not passed else None
                    )
                )

            except Exception as e:
                results.append(
                    RuleResult(rule_id, False, f"Execution error: {e}")
                )

        return results




"""
        )

    with open(f"{OUT_DIR}/validation/rules_v1.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """
class StatusCodeRule:
    def validate(self, response, config):
        if response.status_code >= 500:
            raise AssertionError(f"Server error: {response.status_code}")

class ResponseTimeRule:
    def validate(self, response, config):
        if response.elapsed.total_seconds() * 1000 > config["max_ms"]:
            raise AssertionError("SLA breached")

class HeaderRule:
    def validate(self, response, config):
        for h in config["required"]:
            if h not in response.headers:
                raise AssertionError(f"Missing header: {h}")

class EmptyResponseRule:
    def validate(self, response, config):
        if not response.content:
            raise AssertionError("Empty response")
"""
        )

    with open(f"{OUT_DIR}/validation/rule_engine.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """
import yaml
from .rules_v1 import *
from .custom_rule_engine import CustomRuleEngine

RULES = {
    "status_code": StatusCodeRule(),
    "response_time": ResponseTimeRule(),
    "headers": HeaderRule(),
    "empty_response": EmptyResponseRule(),
}

class ValidationEngine:
    def __init__(self, core_config, custom_rule_file):
        with open(core_config) as f:
            self.core_rules = yaml.safe_load(f)["rules"]

        self.custom_engine = CustomRuleEngine(custom_rule_file)

    def validate(self, response):
        # Built-in rules (fail-fast)
        for name, rule in RULES.items():
            cfg = self.core_rules.get(name)
            if cfg and cfg.get("enabled"):
                rule.validate(response, cfg)

        # Custom rules (collect results)
        results = self.custom_engine.validate(response)

        failures = [r for r in results if not r.passed]
        if failures:
            messages = "\\n".join(str(f) for f in failures)
            raise AssertionError(f"Custom rule failures:\\n{messages}")

        return results

"""
        )
