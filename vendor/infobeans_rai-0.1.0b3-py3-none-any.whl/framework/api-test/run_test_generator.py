# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import os
import sys
import subprocess
from loguru import logger


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", help="Output directory for generated tests", required=False)
    parser.add_argument("--schema-file", help="Path to the local schema file", required=False)
    args, unknown = parser.parse_known_args()

    # Pass args to child scripts
    extra_args = []
    if args.output:
        extra_args += ["--output", args.output]
    if args.schema_file:
        extra_args += ["--schema-file", args.schema_file]

    if args.schema_file and os.path.exists(args.schema_file):
        logger.success("API schema detected — running documented API generator")

        # Add the current directory (framework/api-test) to PYTHONPATH
        env = os.environ.copy()
        env["PYTHONPATH"] = os.path.dirname(os.path.abspath(__file__)) + os.pathsep + env.get("PYTHONPATH", "")

        subprocess.check_call(
            [sys.executable, "documented-new.py"] + extra_args,
            env=env
        )
    else:
        logger.debug("No API schema detected — running undocumented API generator")
        subprocess.check_call(
            [sys.executable, "test_generator_undocumented.py"] + extra_args
        )

if __name__ == "__main__":
    main()
