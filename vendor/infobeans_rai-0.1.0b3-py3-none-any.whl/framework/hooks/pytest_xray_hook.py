# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import os

import pytest

from framework.plugins.jira.reporter import XrayReporter


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """
    Attach the `xray` marker value (if present) into the test report's user_properties.
    Also capture evidence (screenshots from page fixture) on test failure via XrayReporter.

    This ensures pytest-json-report will include the marker value under each test's
    `user_properties` section so external consumers (like the QA runner) can pick it up.
    Evidence captured on failure will be saved to disk for collection by XrayPlugin.
    Works with pytest-xdist parallel execution.
    """
    outcome = yield
    rep = outcome.get_result()

    # Attach xray marker value to user_properties
    m = item.get_closest_marker("xray")
    if m and m.args:
        xray_val = str(m.args[0])
        # ensure user_properties exists
        if not hasattr(rep, "user_properties") or rep.user_properties is None:
            rep.user_properties = []
        rep.user_properties.append(("xray", xray_val))

    # Capture evidence on test failure
    # Only capture during the test call phase when failure occurs
    if call.when == "call" and rep.failed:
        # Get evidence directory from environment (set by runner.py)
        evidence_dir = os.environ.get("IBTEST_XRAY_EVIDENCE_DIR")

        # Create reporter instance with evidence directory
        # Reporter will use this directory to store evidence files
        reporter = XrayReporter(evidence_dir=evidence_dir)

        # Try to get the page fixture for screenshot capture
        page = None
        try:
            # Attempt to get page fixture if available
            if hasattr(item, "_request") and item._request:
                page = item._request.getfixturevalue("page")
            else:
                page = item.funcargs.get("page") if hasattr(item, "funcargs") else None
        except Exception:
            # Page fixture not available, continue without screenshot
            page = None

        # Handle the failure and capture screenshot if page is available
        if page:
            reporter.handle_failure(item, page=page)
