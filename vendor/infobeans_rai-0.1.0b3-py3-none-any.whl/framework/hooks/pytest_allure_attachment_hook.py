# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import pytest

from framework.core.utils import get_logger
from framework.plugins.allure.reporter import AllurePytestReporter

logger = get_logger()


def pytest_configure(config):
    """Initialize Allure reporter."""
    config._allure_reporter = AllurePytestReporter()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """Capture test failures and attach details."""
    outcome = yield
    report = outcome.get_result()

    if report.failed and hasattr(item.config, "_allure_reporter"):
        item.config._allure_reporter.handle_failure(item, call)
