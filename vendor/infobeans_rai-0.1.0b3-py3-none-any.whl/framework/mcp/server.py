# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import asyncio
import contextlib
import json
import logging
import os
import shutil
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any

import mcp.types as types
from mcp.server import Server
from mcp.server.stdio import stdio_server

from framework.core.cli import runner as cli_runner
from framework.core.utils import get_logger, parse_bool
from framework.scaffold_suite.scaffold import create_scaffold, setup_pipeline_files

logger = get_logger()

SERVER_NAME = "infobeans-rai-mcp"
server = Server(SERVER_NAME)

# ---------------------------------------------------------------------------
# Job store — in-memory dict + a jobs/ directory for persistence across polls.
# Key: job_id (str UUID4)
# Value: dict with keys: status, start_time, end_time, exit_code, summary,
#        error, app_name, working_dir, xray_enabled
# ---------------------------------------------------------------------------
_jobs: dict[str, dict] = {}
_jobs_lock = threading.Lock()

# Serialize pytest.main() calls — it has global state and must not run concurrently.
_run_lock = threading.Lock()

# Serialize in-process API test generation — sys.argv/sys.path are global.
_api_gen_lock = threading.Lock()


def _get_workspace() -> str:
    return os.environ.get("INFOBEANS_RAI_WORKSPACE", os.getcwd())


def _text(data: Any) -> list[types.TextContent]:
    text = json.dumps(data) if not isinstance(data, str) else data
    return [types.TextContent(type="text", text=text)]


def _jobs_dir(working_dir: str) -> Path:
    p = Path(working_dir) / ".mcp_jobs"
    p.mkdir(exist_ok=True)
    return p


def _save_job(job_id: str, state: dict, working_dir: str) -> None:
    """Persist job state to disk so get_run_status can read it."""
    with _jobs_lock:
        _jobs[job_id] = state
    try:
        path = _jobs_dir(working_dir) / f"{job_id}.json"
        path.write_text(json.dumps(state), encoding="utf-8")
    except Exception as e:
        logging.getLogger(__name__).warning(f"Could not persist job {job_id} to disk: {e}")


def _load_job(job_id: str) -> dict | None:
    """Load job from memory first, then fall back to disk scan."""
    with _jobs_lock:
        if job_id in _jobs:
            return _jobs[job_id]
    # Scan all known working dirs for the job file
    workspace = _get_workspace()
    path = _jobs_dir(workspace) / f"{job_id}.json"
    if path.exists():
        state = json.loads(path.read_text(encoding="utf-8"))
        with _jobs_lock:
            _jobs[job_id] = state
        return state
    return None


# ---------------------------------------------------------------------------
# Background worker — runs tests + optional Xray upload in a daemon thread
# ---------------------------------------------------------------------------

def _run_tests_worker(
    job_id: str,
    app_name: str,
    working_dir: str,
    apps_dir: str,
    config_file: str,
    workers_count: str | None,
    split_level: str,
    reruns: int,
    reruns_delay: int,
    generate_allure_report: bool,
):
    """
    Runs in a daemon thread.
    Phase 1: pytest  (skip Xray upload via env var)
    Phase 2: Xray upload using the saved summary (if Xray is configured)
    """

    def _update(patch: dict):
        state = _load_job(job_id) or {}
        state.update(patch)
        _save_job(job_id, state, working_dir)

    # ── helpers to redirect logger handlers away from stdout ─────────────────
    def _redirect_logger():
        ibtest_logger = logging.getLogger("TestAutomationFramework")
        redirected = []
        for h in ibtest_logger.handlers:
            if (isinstance(h, logging.StreamHandler)
                    and not isinstance(h, logging.FileHandler)
                    and h.stream is not sys.stderr):
                redirected.append((h, h.stream))
                h.stream = sys.stderr
        return redirected

    def _restore_logger(redirected):
        for h, stream in redirected:
            h.stream = stream

    original_dir = os.getcwd()

    # ── Phase 1: run pytest (no Xray) ────────────────────────────────────────
    _update({"status": "running", "phase": "testing"})
    try:
        redirected = _redirect_logger()
        # Tell the Xray plugin to skip upload during this pytest session.
        os.environ["IBTEST_MCP_SKIP_XRAY"] = "1"
        try:
            os.chdir(working_dir)
            if parse_bool(os.getenv("IS_WHEEL_BUILD", "true")) and working_dir not in sys.path:
                sys.path.append(working_dir)
            # Load .env so that config.yaml placeholders (e.g. ${XRAY_API_BASE_URL})
            # resolve correctly — the CLI does this in run_command; MCP must do it here.
            try:
                from dotenv import load_dotenv
                load_dotenv(os.path.join(working_dir, ".env"), override=False)
            except Exception:
                pass
            with _run_lock:
                with contextlib.redirect_stdout(sys.stderr):
                    exit_code, summary, _ = cli_runner.run_app(
                        app_name,
                        apps_dir,
                        reruns=reruns,
                        reruns_delay=reruns_delay,
                        config_file=config_file,
                        split_level=split_level,
                        workers_count=workers_count,
                        generate_allure_report=generate_allure_report,
                        extras=["--capture=sys"],
                    )
        finally:
            os.environ.pop("IBTEST_MCP_SKIP_XRAY", None)
            _restore_logger(redirected)
            os.chdir(original_dir)

        _update({
            "status": "completed",
            "phase": "testing_done",
            "exit_code": int(exit_code) if exit_code is not None else None,
            "summary": summary or {},
            "json_report": str(_) if _ else None,
            "end_time": time.time(),
        })

    except Exception as exc:
        _update({
            "status": "error",
            "phase": "testing",
            "error": str(exc),
            "end_time": time.time(),
        })
        return

    # ── Phase 2: Xray upload ──────────────────────────────────────────────────
    # Check whether Xray is configured for this app.
    try:
        from framework.core.cli.runner import load_app_config, load_plugins, PluginManager
        config = load_app_config(app_name, yaml_file=config_file)
        reporting = config.get("reporting", [])
        xray_entry = next(
            (e for e in reporting if e.get("name") == "XrayPlugin" and e.get("enabled")),
            None,
        )
    except Exception:
        xray_entry = None

    if not xray_entry:
        _update({"xray_status": "skipped", "xray_message": "XrayPlugin not enabled for this app."})
        return

    _update({"phase": "uploading", "xray_status": "uploading"})
    try:
        redirected = _redirect_logger()
        try:
            os.chdir(working_dir)
            plugins = load_plugins(reporting, config)
            plugin_manager = PluginManager(plugins)
            state = _load_job(job_id)
            summary = state.get("summary", {})
            context = {
                "app_name": app_name,
                "config": config,
                "app_path": os.path.join(apps_dir, app_name),
                "summary": summary,
            }
            with contextlib.redirect_stdout(sys.stderr):
                plugin_manager.session_start(context)
                plugin_manager.session_finish(context)
        finally:
            _restore_logger(redirected)
            os.chdir(original_dir)

        _update({
            "phase": "done",
            "xray_status": "uploaded",
            "xray_message": "Results uploaded to Xray successfully.",
        })

    except Exception as exc:
        _update({
            "phase": "done",
            "xray_status": "error",
            "xray_message": str(exc),
        })


# ---------------------------------------------------------------------------
# Tool registry
# ---------------------------------------------------------------------------

@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="run_tests",
            description=(
                "Start QA tests for a specific app using infobeans-rai. "
                "Returns immediately with a job_id — tests run in the background. "
                "After calling this tool, call get_run_status with the job_id to poll "
                "for results. When status is 'completed', call upload_to_xray if Xray "
                "is configured."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "App folder name under apps/, e.g. 'saucedemo'.",
                    },
                    "config_file": {
                        "type": "string",
                        "description": "Config YAML filename inside the app folder (default: config.yaml).",
                        "default": "config.yaml",
                    },
                    "workers_count": {
                        "type": "string",
                        "description": "Number of parallel pytest-xdist workers (default: auto).",
                    },
                    "split_level": {
                        "type": "string",
                        "enum": ["test_file", "module"],
                        "description": "How to split tests across workers (default: test_file).",
                        "default": "test_file",
                    },
                    "reruns": {
                        "type": "integer",
                        "description": "Re-run attempts for failing tests (default: 3).",
                        "default": 3,
                    },
                    "reruns_delay": {
                        "type": "integer",
                        "description": "Delay in seconds between reruns (default: 7).",
                        "default": 7,
                    },
                    "generate_allure_report": {
                        "type": "boolean",
                        "description": "Generate Allure HTML report after execution (default: false).",
                        "default": False,
                    },
                    "working_dir": {
                        "type": "string",
                        "description": "Root directory of the infobeans-rai project. Overrides INFOBEANS_RAI_WORKSPACE.",
                    },
                },
                "required": ["app_name"],
            },
        ),
        types.Tool(
            name="get_run_status",
            description=(
                "Check the status of a background test run started by run_tests. "
                "Poll every 15 seconds until status is 'completed' or 'error'. "
                "When completed, call upload_to_xray with the same job_id if Xray is configured."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "job_id": {
                        "type": "string",
                        "description": "The job_id returned by run_tests.",
                    },
                },
                "required": ["job_id"],
            },
        ),
        types.Tool(
            name="upload_to_xray",
            description=(
                "Upload test results for a completed job to Jira Xray. "
                "Call this after get_run_status returns status 'completed'. "
                "Skipped automatically if XrayPlugin is not enabled for the app."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "job_id": {
                        "type": "string",
                        "description": "The job_id returned by run_tests.",
                    },
                },
                "required": ["job_id"],
            },
        ),
        types.Tool(
            name="setup_app",
            description=(
                "Create a new test suite scaffold under apps/ in the infobeans-rai project "
                "and optionally configure a .env file with Xray/Jira credentials. "
                "If the app directory already exists, this tool returns a confirmation "
                "request — call it again with overwrite=true to replace it, or "
                "overwrite=false to skip scaffold creation and only update .env. "
                "All environment variables are optional — omitted ones are written as "
                "placeholder values so the .env file is always created."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "App name — alphanumeric and underscores only.",
                    },
                    "scaffold": {
                        "type": "boolean",
                        "description": (
                            "Use the full scaffold template with example tests (true), "
                            "or a minimal empty template (false, default)."
                        ),
                        "default": False,
                    },
                    "overwrite": {
                        "type": "boolean",
                        "description": (
                            "Only required when the app directory already exists. "
                            "true = delete and recreate the app folder. "
                            "false = skip scaffold, only update .env. "
                            "Omit on first call — the tool will ask if needed."
                        ),
                    },
                    "xray_client_id": {"type": "string"},
                    "xray_client_secret": {"type": "string"},
                    "xray_api_base_url": {
                        "type": "string",
                        "default": "https://xray.cloud.getxray.app",
                    },
                    "xray_project_key": {"type": "string"},
                    "xray_project_id": {"type": "string"},
                    "jira_url": {"type": "string"},
                    "jira_api_email": {"type": "string"},
                    "jira_api_token": {"type": "string"},
                    "working_dir": {"type": "string"},
                },
                "required": ["app_name"],
            },
        ),
        types.Tool(
            name="setup_pipeline",
            description=(
                "Set up GitHub Actions pipeline files (.github/, requirements.txt, etc.) "
                "in the infobeans-rai project root."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "working_dir": {"type": "string"},
                },
            },
        ),
        types.Tool(
            name="generate_api_test",
            description=(
                "Auto-generate API test suites from a Swagger/OpenAPI schema. "
                "Provide exactly one of schema_url or schema_file."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "folder_name": {
                        "type": "string",
                        "default": "generated_tests",
                    },
                    "schema_url": {"type": "string"},
                    "schema_file": {"type": "string"},
                    "working_dir": {"type": "string"},
                },
                "required": ["folder_name"],
            },
        ),
        types.Tool(
            name="generate_report",
            description=(
                "Generate an executive PDF report from a pytest JSON results file. "
                "Provide app_name to auto-locate the results file and save the PDF "
                "in apps/<app_name>/reports/. "
                "Always returns the exact output path of the generated PDF."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": (
                            "App folder name under apps/. When provided, automatically "
                            "locates apps/<app_name>/reports/pytest_report.json and saves "
                            "the PDF to apps/<app_name>/reports/infobeans-rai_test_summary.pdf."
                        ),
                    },
                    "results_file": {
                        "type": "string",
                        "description": (
                            "Explicit path to the pytest JSON results file. "
                            "Only needed if app_name is not provided."
                        ),
                    },
                    "report_title": {
                        "type": "string",
                        "default": "Test Execution Summary",
                    },
                    "output": {
                        "type": "string",
                        "description": (
                            "Output PDF file path. If relative, resolved against working_dir. "
                            "If omitted, saved as infobeans-rai_test_summary.pdf in the reports directory."
                        ),
                    },
                    "detailed": {"type": "boolean", "default": False},
                    "working_dir": {
                        "type": "string",
                        "description": "Root directory of the infobeans-rai project. Overrides INFOBEANS_RAI_WORKSPACE.",
                    },
                },
            },
        ),
    ]


# ---------------------------------------------------------------------------
# Tool dispatcher
# ---------------------------------------------------------------------------

@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[types.TextContent]:
    try:
        if name == "run_tests":
            return await _handle_run_tests(arguments)
        elif name == "get_run_status":
            return _handle_get_run_status(arguments)
        elif name == "upload_to_xray":
            return await _handle_upload_to_xray(arguments)
        elif name == "setup_app":
            return await _handle_setup_app(arguments)
        elif name == "setup_pipeline":
            return await _handle_setup_pipeline(arguments)
        elif name == "generate_api_test":
            return await _handle_generate_api_test(arguments)
        elif name == "generate_report":
            return await _handle_generate_report(arguments)
        else:
            raise ValueError(f"Unknown tool: {name}")
    except Exception as exc:
        return _text({"status": "error", "error": str(exc)})


# ---------------------------------------------------------------------------
# run_tests — launches background thread, returns immediately
# ---------------------------------------------------------------------------

async def _handle_run_tests(arguments: dict) -> list[types.TextContent]:
    app_name = arguments.get("app_name")
    if not app_name:
        raise ValueError("app_name is required")

    working_dir = arguments.get("working_dir") or _get_workspace()
    if not os.path.isdir(working_dir):
        raise ValueError(f"working_dir does not exist: {working_dir}")

    apps_dir = os.path.join(working_dir, "apps")
    if not os.path.isdir(apps_dir):
        raise ValueError(f"No 'apps/' directory found in: {working_dir}")

    app_dir = os.path.join(apps_dir, app_name)
    if not os.path.isdir(app_dir):
        raise ValueError(
            f"App '{app_name}' not found at {app_dir}. "
            "Run setup_app first to create the app scaffold."
        )

    job_id = str(uuid.uuid4())[:8]

    initial_state = {
        "job_id": job_id,
        "status": "starting",
        "phase": "queued",
        "app_name": app_name,
        "working_dir": working_dir,
        "start_time": time.time(),
    }
    _save_job(job_id, initial_state, working_dir)

    t = threading.Thread(
        target=_run_tests_worker,
        kwargs=dict(
            job_id=job_id,
            app_name=app_name,
            working_dir=working_dir,
            apps_dir=apps_dir,
            config_file=arguments.get("config_file", "config.yaml"),
            workers_count=arguments.get("workers_count"),
            split_level=arguments.get("split_level", "test_file"),
            reruns=arguments.get("reruns", 3),
            reruns_delay=arguments.get("reruns_delay", 7),
            generate_allure_report=arguments.get("generate_allure_report", False),
        ),
        daemon=True,
        name=f"infobeans-rai-job-{job_id}",
    )
    t.start()

    return _text({
        "job_id": job_id,
        "status": "started",
        "app_name": app_name,
        "hint": (
            f"Tell the user: 'Tests started for {app_name}. Job ID: {job_id}'. "
            f"Then call get_run_status with job_id='{job_id}' every 15 seconds until "
            f"status is 'completed' or 'error'. "
            f"Once completed, call upload_to_xray with the same job_id "
            f"to push results to Jira Xray (skipped automatically if not configured)."
        ),
    })


# ---------------------------------------------------------------------------
# get_run_status — synchronous poll, no async needed
# ---------------------------------------------------------------------------

def _handle_get_run_status(arguments: dict) -> list[types.TextContent]:
    job_id = arguments.get("job_id")
    if not job_id:
        raise ValueError("job_id is required")

    state = _load_job(job_id)
    if not state:
        return _text({"status": "error", "error": f"Unknown job_id: {job_id}"})

    elapsed = round(time.time() - state.get("start_time", time.time()), 1)
    status = state.get("status")
    phase = state.get("phase")

    response: dict[str, Any] = {
        "job_id": job_id,
        "status": status,
        "phase": phase,
        "app_name": state.get("app_name"),
        "elapsed_seconds": elapsed,
    }

    if status == "running":
        response["hint"] = "Tests still running. Call get_run_status again in 15 seconds."

    elif status == "completed":
        summary = state.get("summary", {})
        response["summary"] = summary
        response["exit_code"] = state.get("exit_code")
        xray_status = state.get("xray_status")
        if xray_status == "uploaded":
            response["xray_status"] = "uploaded"
            response["xray_message"] = state.get("xray_message")
            response["hint"] = "Tests completed and results uploaded to Xray."
        elif xray_status == "skipped":
            response["xray_status"] = "skipped"
            response["hint"] = (
                "Tests completed. Xray upload skipped (not configured). "
                "No further action needed."
            )
        elif xray_status in ("error", "uploading", None):
            response["hint"] = (
                f"Tests completed. Call upload_to_xray with job_id='{job_id}' "
                f"to push results to Jira Xray."
            )

    elif status == "error":
        response["error"] = state.get("error")
        response["hint"] = "Test run failed. Check error details above."

    return _text(response)


# ---------------------------------------------------------------------------
# upload_to_xray — explicit upload for a completed job
# ---------------------------------------------------------------------------

async def _handle_upload_to_xray(arguments: dict) -> list[types.TextContent]:
    job_id = arguments.get("job_id")
    if not job_id:
        raise ValueError("job_id is required")

    state = _load_job(job_id)
    if not state:
        return _text({"status": "error", "error": f"Unknown job_id: {job_id}"})

    if state.get("status") != "completed":
        return _text({
            "status": "error",
            "error": f"Job {job_id} is not completed yet (status: {state.get('status')}). "
                     "Wait for get_run_status to return status=completed first.",
        })

    if state.get("xray_status") == "uploaded":
        return _text({
            "status": "already_uploaded",
            "message": "Results were already uploaded to Xray by the background worker.",
            "xray_message": state.get("xray_message"),
        })

    app_name = state.get("app_name")
    if not app_name:
        return _text({"status": "error", "error": f"Job {job_id} has no app_name recorded. Cannot upload to Xray."})
    working_dir = state.get("working_dir") or _get_workspace()
    apps_dir = os.path.join(working_dir, "apps")
    summary = state.get("summary", {})

    def _run():
        from framework.core.cli.runner import load_app_config, load_plugins, PluginManager

        ibtest_logger = logging.getLogger("TestAutomationFramework")
        redirected = [(h, h.stream) for h in ibtest_logger.handlers
                      if isinstance(h, logging.StreamHandler)
                      and not isinstance(h, logging.FileHandler)
                      and h.stream is not sys.stderr]
        for h, _ in redirected:
            h.stream = sys.stderr

        original_dir = os.getcwd()
        try:
            os.chdir(working_dir)
            try:
                from dotenv import load_dotenv
                load_dotenv(os.path.join(working_dir, ".env"), override=False)
            except Exception:
                pass
            config = load_app_config(app_name)
            reporting = config.get("reporting", [])
            xray_entry = next(
                (e for e in reporting if e.get("name") == "XrayPlugin" and e.get("enabled")),
                None,
            )
            if not xray_entry:
                return "skipped", "XrayPlugin not enabled for this app."

            plugins = load_plugins(reporting, config)
            plugin_manager = PluginManager(plugins)
            context = {
                "app_name": app_name,
                "config": config,
                "app_path": os.path.join(apps_dir, app_name),
                "summary": summary,
            }
            with contextlib.redirect_stdout(sys.stderr):
                plugin_manager.session_start(context)
                plugin_manager.session_finish(context)
            return "uploaded", "Results uploaded to Xray successfully."
        finally:
            for h, stream in redirected:
                h.stream = stream
            os.chdir(original_dir)

    loop = asyncio.get_running_loop()
    xray_status, xray_message = await loop.run_in_executor(None, _run)

    state["xray_status"] = xray_status
    state["xray_message"] = xray_message
    _save_job(job_id, state, working_dir)

    return _text({
        "job_id": job_id,
        "xray_status": xray_status,
        "message": xray_message,
    })


# ---------------------------------------------------------------------------
# setup_app
# ---------------------------------------------------------------------------

async def _handle_setup_app(arguments: dict) -> list[types.TextContent]:
    import re

    app_name = arguments.get("app_name")
    if not app_name:
        raise ValueError("app_name is required")
    if not re.match(r"^[a-zA-Z0-9_]+$", app_name):
        raise ValueError("app_name must contain only alphanumeric characters and underscores")

    scaffold = arguments.get("scaffold", False)
    working_dir = arguments.get("working_dir") or _get_workspace()
    overwrite = arguments.get("overwrite")  # None = not yet decided

    _PH = lambda key: arguments.get(key) or f"<{key.upper()}>"
    env_values = {
        "PYTEST_XDIST_WORKER_COUNT": "auto",
        "XRAY_CLIENT_ID": _PH("xray_client_id"),
        "XRAY_CLIENT_SECRET": _PH("xray_client_secret"),
        "XRAY_API_BASE_URL": arguments.get("xray_api_base_url") or "https://xray.cloud.getxray.app",
        "XRAY_PROJECT_KEY": _PH("xray_project_key"),
        "XRAY_PROJECT_ID": _PH("xray_project_id"),
        "JIRA_URL": _PH("jira_url"),
        "JIRA_API_EMAIL": _PH("jira_api_email"),
        "JIRA_API_TOKEN": _PH("jira_api_token"),
    }

    app_dir = Path(working_dir) / "apps" / app_name

    # ── Overwrite guard ──────────────────────────────────────────────────────
    if app_dir.exists():
        if overwrite is None:
            # Ask the user what to do — do not proceed yet.
            return _text({
                "status": "needs_confirmation",
                "message": (
                    f"App '{app_name}' already exists at {app_dir}. "
                    "What would you like to do?"
                ),
                "hint": (
                    f"Call setup_app again with the same arguments plus:\n"
                    f"  overwrite=true  → delete and recreate the app folder\n"
                    f"  overwrite=false → keep existing files, only update .env"
                ),
            })
        elif overwrite is True:
            # Delete the existing folder so scaffold starts fresh.
            shutil.rmtree(app_dir)

    # After potential rmtree: skip scaffold only when dir still exists (overwrite=False).
    skip_scaffold = app_dir.exists() and overwrite is False

    def _run():
        ibtest_logger = logging.getLogger("TestAutomationFramework")
        redirected = [(h, h.stream) for h in ibtest_logger.handlers
                      if isinstance(h, logging.StreamHandler)
                      and not isinstance(h, logging.FileHandler)
                      and h.stream is not sys.stderr]
        for h, _ in redirected:
            h.stream = sys.stderr
        original_dir = os.getcwd()
        try:
            os.chdir(working_dir)
            with contextlib.redirect_stdout(sys.stderr):
                create_scaffold(app_name, scaffold_template="full" if scaffold else None)
        except SystemExit as exc:
            # scaffold.py calls sys.exit(1) on errors.
            # Letting SystemExit propagate through the MCP async TaskGroup crashes the
            # entire server process. Convert it to a RuntimeError so the tool call
            # returns a clean error response instead.
            raise RuntimeError(
                f"Scaffold failed for app '{app_name}'. "
                "Check that the working directory is correct."
            ) from exc
        finally:
            for h, stream in redirected:
                h.stream = stream
            os.chdir(original_dir)

    def _write_env():
        env_path = Path(working_dir) / ".env"
        existing: dict[str, str] = {}
        if env_path.exists():
            for raw_line in env_path.read_text(encoding="utf-8").splitlines():
                line = raw_line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, _, v = line.partition("=")
                    existing[k.strip()] = v.strip().strip('"')
        merged: dict[str, str] = {}
        for key, new_val in env_values.items():
            old_val = existing.get(key, "")
            if old_val and not (old_val.startswith("<") and old_val.endswith(">")):
                merged[key] = old_val
            else:
                merged[key] = new_val
        lines = [
            "# infobeans-rai environment configuration",
            "# Fill in placeholder values (<...>) with your actual credentials.",
            "",
        ]
        for key, val in merged.items():
            needs_quote = True
            lines.append(f'{key}="{val}"' if needs_quote else f"{key}={val}")
        env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return env_path

    loop = asyncio.get_running_loop()
    if not skip_scaffold:
        await loop.run_in_executor(None, _run)
    env_path = await loop.run_in_executor(None, _write_env)

    template = "scaffold" if scaffold else "minimal"
    pending = [k for k, v in env_values.items() if v.startswith("<") and v.endswith(">")]
    filled = [k for k, v in env_values.items()
              if not (v.startswith("<") and v.endswith(">"))
              and k not in ("PYTEST_XDIST_WORKER_COUNT", "XRAY_API_BASE_URL")]

    if skip_scaffold:
        msg = f"App '{app_name}' already exists — scaffold skipped, existing files kept. .env updated at {env_path}."
    elif overwrite is True:
        msg = f"App '{app_name}' replaced using {template} template. .env written to {env_path}."
    else:
        msg = f"App '{app_name}' created using {template} template. .env written to {env_path}."
    if pending:
        msg += f" Fill in placeholders for: {', '.join(pending)}."

    return _text({
        "status": "success",
        "message": msg,
        "env_file": str(env_path),
        "env_configured": filled,
        "env_pending": pending,
    })


# ---------------------------------------------------------------------------
# setup_pipeline
# ---------------------------------------------------------------------------

async def _handle_setup_pipeline(arguments: dict) -> list[types.TextContent]:
    working_dir = arguments.get("working_dir") or _get_workspace()
    if not os.path.isdir(working_dir):
        raise ValueError(f"working_dir does not exist: {working_dir}")

    def _run():
        ibtest_logger = logging.getLogger("TestAutomationFramework")
        redirected = [(h, h.stream) for h in ibtest_logger.handlers
                      if isinstance(h, logging.StreamHandler)
                      and not isinstance(h, logging.FileHandler)
                      and h.stream is not sys.stderr]
        for h, _ in redirected:
            h.stream = sys.stderr
        try:
            with contextlib.redirect_stdout(sys.stderr):
                setup_pipeline_files(Path(working_dir))
        except SystemExit as exc:
            raise RuntimeError("setup_pipeline failed. Check that the working directory is correct.") from exc
        finally:
            for h, stream in redirected:
                h.stream = stream

    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, _run)
    return _text({"status": "success", "message": "Pipeline files set up successfully."})

# ---------------------------------------------------------------------------
# generate_api_test
# ---------------------------------------------------------------------------

async def _handle_generate_api_test(arguments: dict) -> list[types.TextContent]:
    schema_url = arguments.get("schema_url")
    schema_file = arguments.get("schema_file")

    if schema_url and schema_file:
        raise ValueError("Provide either schema_url or schema_file, not both.")
    if not schema_url and not schema_file:
        raise ValueError("Provide either schema_url or schema_file.")

    folder_name = arguments.get("folder_name", "generated_tests")
    working_dir = arguments.get("working_dir") or _get_workspace()
    if not os.path.isdir(working_dir):
        raise ValueError(f"working_dir does not exist: {working_dir}")

    def _run():
        import importlib.util as _ilu
        import runpy
        import tempfile
        import requests as req

        # Locate the api-test directory (works for both dev tree and wheel installs).
        api_test_dir = os.path.join(working_dir, "framework", "api-test")
        if not os.path.isdir(api_test_dir):
            framework_root = os.environ.get("FRAMEWORK_ROOT")
            if not framework_root:
                try:
                    spec = _ilu.find_spec("framework")
                    if spec and spec.submodule_search_locations:
                        framework_root = list(spec.submodule_search_locations)[0]
                except Exception:
                    pass
            if framework_root:
                api_test_dir = os.path.join(framework_root, "api-test")

        script_path = os.path.join(api_test_dir, "documented-new.py")
        if not os.path.exists(script_path):
            raise FileNotFoundError(f"Test generator script not found at: {script_path}")

        target_output_dir = os.path.join(working_dir, "apps", folder_name)

        # Download schema to a temp file so we never write into api_test_dir
        # (which may be read-only inside a wheel/site-packages install).
        tmp_schema = None
        try:
            if schema_url:
                resp = req.get(schema_url, timeout=30)
                resp.raise_for_status()
                ext = ".json" if "json" in resp.headers.get("Content-Type", "") else ".yaml"
                fd, tmp_schema = tempfile.mkstemp(suffix=ext)
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(resp.text)
                local_schema = tmp_schema
            else:
                if not os.path.isfile(schema_file):
                    raise FileNotFoundError(f"Schema file does not exist: {schema_file}")
                local_schema = schema_file

            # Run the generator in-process to avoid subprocess startup latency
            # (two nested Python launches on Windows easily exceeds the 60-second
            # MCP client timeout).  sys.argv and sys.path are global, so serialise.
            _gen_prefixes = ("common", "generators", "methods_tests")
            with _api_gen_lock:
                # Evict any stale cached generator modules so constants.py
                # re-reads sys.argv with the new --output / --schema-file values.
                evicted = {
                    k: sys.modules.pop(k) for k in list(sys.modules)
                    if any(k == p or k.startswith(p + ".") for p in _gen_prefixes)
                }
                old_argv = sys.argv[:]
                path_inserted = False
                try:
                    sys.argv = [
                        "documented-new.py",
                        "--output", target_output_dir,
                        "--schema-file", local_schema,
                    ]
                    if api_test_dir not in sys.path:
                        sys.path.insert(0, api_test_dir)
                        path_inserted = True
                    with contextlib.redirect_stdout(sys.stderr):
                        runpy.run_path(script_path, run_name="__main__")
                finally:
                    sys.argv = old_argv
                    if path_inserted and api_test_dir in sys.path:
                        sys.path.remove(api_test_dir)
                    # Remove freshly imported generator modules; restore originals.
                    for k in list(sys.modules):
                        if any(k == p or k.startswith(p + ".") for p in _gen_prefixes):
                            del sys.modules[k]
                    sys.modules.update(evicted)
        finally:
            if tmp_schema:
                try:
                    os.unlink(tmp_schema)
                except Exception:
                    pass

        return target_output_dir

    loop = asyncio.get_running_loop()
    output_dir = await loop.run_in_executor(None, _run)
    return _text({"status": "success", "message": "API tests generated.", "output_dir": output_dir})


# ---------------------------------------------------------------------------
# generate_report
# ---------------------------------------------------------------------------

async def _handle_generate_report(arguments: dict) -> list[types.TextContent]:
    from framework.core.utils.generate_pytest_report import PytestReportGenerator

    working_dir = Path(arguments.get("working_dir") or _get_workspace())
    report_title = arguments.get("report_title") or "Test Execution Summary"
    detailed = arguments.get("detailed", False)
    app_name = arguments.get("app_name")

    # Resolve results_file to an absolute path.
    results_file_arg = arguments.get("results_file")
    if results_file_arg:
        results_file = Path(results_file_arg)
        if not results_file.is_absolute():
            results_file = working_dir / results_file
    elif app_name:
        # Standard location: apps/<app_name>/reports/pytest_report.json
        results_file = working_dir / "apps" / app_name / "reports" / "pytest_report.json"
    else:
        raise ValueError(
            "Provide app_name (recommended) or results_file explicitly. "
            "app_name will auto-locate apps/<app_name>/reports/pytest_report.json."
        )

    if not results_file.exists():
        raise FileNotFoundError(
            f"Results file not found: {results_file}. "
            "Run tests first to generate the results file."
        )

    # Resolve output path to an absolute path.
    output_arg = arguments.get("output")
    if output_arg:
        output_path = Path(output_arg)
        if not output_path.is_absolute():
            output_path = working_dir / output_path
    else:
        # Default: same reports/ directory as the results file.
        output_path = results_file.parent / "infobeans-rai_test_summary.pdf"

    # Ensure output directory exists.
    output_path.parent.mkdir(parents=True, exist_ok=True)

    def _run():
        with contextlib.redirect_stdout(sys.stderr):
            generator = PytestReportGenerator(
                results_file=str(results_file),
                output_file=str(output_path),
                detailed=detailed,
                report_title=report_title,
            )
            return generator.generate_report()

    loop = asyncio.get_running_loop()
    actual_output = await loop.run_in_executor(None, _run)
    if not actual_output or not Path(actual_output).exists():
        raise RuntimeError(
            f"Report generation failed — output file was not created. "
            f"Expected at: {output_path}"
        )
    output_uri = Path(actual_output).as_uri()
    return _text({
        "status": "success",
        "message": "Report generated successfully.",
        "output": actual_output,
        "output_link": output_uri,
        "hint": f"Present the report path as a clickable link: [infobeans-rai_test_summary.pdf]({output_uri})",
    })


# ---------------------------------------------------------------------------
# Server entry point
# ---------------------------------------------------------------------------

async def run_server():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )
