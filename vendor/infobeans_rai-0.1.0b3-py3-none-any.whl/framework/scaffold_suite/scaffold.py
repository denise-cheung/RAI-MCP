# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import re
import shutil
import sys
from pathlib import Path
from typing import List

from framework.core.utils.logger import get_logger

# --- Constants ---
PYCACHE = "__pycache__"
TEMPLATE_APP_NAME = "saucedemo"
TEMPLATE_SUITE_NAME = "regression"
APPS_DIR_NAME = "apps"
RESOURCES_DIR_NAME = "resources"
COMMON_FILES_DIR_NAME = "common_files"
SCAFFOLD_TEMPLATE_DIR_NAME = "scaffold_template"
TEMPLATE_DIR_NAME = "template"
TEXT_FILE_EXTENSIONS = (
    ".py",
    ".md",
    ".markdown",
    ".yaml",
    ".yml",
    ".txt",
    ".ini",
    ".cfg",
)

# --- Initialise Logger ---
logger = get_logger()


# --- Helper Functions ---


def _replace_placeholders_in_file(file_path: Path, replacements: dict):
    """
    Replaces placeholders in a single file.

    Args:
        file_path: Path to the file to process.
        replacements: A dictionary of placeholder -> new_value.
    """
    if file_path.suffix not in TEXT_FILE_EXTENSIONS:
        return
    try:
        content = file_path.read_text(encoding="utf-8")
        for old, new in replacements.items():
            content = content.replace(old, new)
        file_path.write_text(content, encoding="utf-8")
    except Exception as e:
        logger.warning(f"Could not process file {file_path}: {e}")


def _replace_references_in_file(file_path: Path, replacements: dict):
    """
    Replaces more complex references like imports and paths in a file.

    Args:
        file_path: Path to the file to process.
        replacements: A dictionary of regex_pattern -> replacement_string.
    """
    if file_path.suffix not in (".py", ".yaml", ".yml"):
        return
    try:
        content = file_path.read_text(encoding="utf-8")
        for pattern, replacement in replacements.items():
            content = re.sub(pattern, replacement, content)
        file_path.write_text(content, encoding="utf-8")
    except Exception as e:
        logger.warning(f"Could not process file {file_path}: {e}")


def _copy_item(src: Path, dest: Path):
    """
    Recursively copies a file or directory, ignoring __pycache__.

    Args:
        src: Source path.
        dest: Destination path.
    """
    if src.is_dir():
        shutil.copytree(src, dest, ignore=shutil.ignore_patterns(PYCACHE, "*.pyc"))
    else:
        shutil.copy2(src, dest)


def _copy_and_replace_placeholders_in_dir(
    src_dir: Path, dest_dir: Path, replacements: dict
):
    """
    Copies a directory and replaces placeholders in text files.

    Args:
        src_dir: The source directory.
        dest_dir: The destination directory.
        replacements: A dictionary of placeholder -> new_value.
    """
    if not src_dir.is_dir():
        logger.warning(f"Source for copying is not a directory: {src_dir}")
        return

    # Check if it exists and copy only if it doesn't exist
    if dest_dir.exists():
        return

    _copy_item(src_dir, dest_dir)
    for path in dest_dir.rglob("*"):
        if path.is_file():
            _replace_placeholders_in_file(path, replacements)
    logger.info(f"Copied and processed directory {dest_dir}")


def _copy_common_file(
    common_files_dir: Path, dest_dir: Path, item_name: str, replacements: dict
):
    """
    Copies a single file from the common_files directory if it doesn't exist at the destination.

    Args:
        common_files_dir: Path to the common_files directory.
        dest_dir: The application's destination directory.
        item_name: The name of the file to copy.
        replacements: A dictionary of placeholder -> new_value.
    """
    dest_path = dest_dir / item_name
    if dest_path.exists():
        return

    src_path = common_files_dir / item_name
    if src_path.exists():
        shutil.copy2(src_path, dest_path)
        _replace_placeholders_in_file(dest_path, replacements)
        logger.info(f"Copied {item_name} to {dest_path}")
    else:
        logger.warning(f"{item_name} not found in common files at {src_path}")


# --- Core Logic ---


def _find_template_app_path(template_name: str, current_dir: Path) -> Path:
    """
    Determines the path to the scaffold template app.

    Args:
        template_name: The name of the template app (e.g., 'saucedemo').
        current_dir: The directory of the current script.

    Returns:
        The path to the template app.
    """
    # 1. Check in resources/scaffold_template (installed package)
    template_path = (
        current_dir / RESOURCES_DIR_NAME / SCAFFOLD_TEMPLATE_DIR_NAME / template_name
    )
    if template_path.exists():
        return template_path

    # 2. Check in workspace apps folder (development mode)
    workspace_apps = Path.cwd() / APPS_DIR_NAME
    if workspace_apps.exists():
        template_path = workspace_apps / template_name
        if template_path.exists():
            return template_path

    # 3. Fallback to legacy path relative to framework
    framework_root = current_dir.parent.parent
    template_path = framework_root / APPS_DIR_NAME / template_name
    if template_path.exists():
        return template_path

    logger.error(f"Scaffold template '{template_name}' not found.")
    sys.exit(1)


def create_scaffold_from_template_app(
    app_name: str, scaffold_template: str = TEMPLATE_APP_NAME
):
    """
    Creates a project structure by copying from an existing scaffold template app.
    Automatically discovers and copies all suite directories from the template.

    Args:
        app_name: Name for the new application folder.
        scaffold_template: Name of the template app to copy from.
    """
    logger.info(
        f"Creating project from template '{scaffold_template}' for app '{app_name}'"
    )

    current_dir = Path(__file__).parent
    template_app_path = _find_template_app_path(scaffold_template, current_dir)
    logger.info(f"Using scaffold template from: {template_app_path}")

    output_dir = Path.cwd() / APPS_DIR_NAME / app_name
    root_dir = Path.cwd()
    apps_dir = Path.cwd() / APPS_DIR_NAME
    if output_dir.exists():
        logger.error(f"Directory '{app_name}' already exists at {output_dir}")
        sys.exit(1)

    output_dir.mkdir(parents=True)
    logger.info(f"Created app directory: {output_dir}")

    # Create __init__.py in apps directory if it doesn't exist
    apps_init_file = apps_dir / "__init__.py"
    if not apps_init_file.exists():
        apps_init_file.touch()
        logger.info(f"Created {apps_init_file}")

    # Items to skip when copying (these are handled separately from common_files)
    skip_items_for_copying = (
        ".github",
        "docs",
        "README.md",
        "RELEASE_NOTES.md",
        ".env_sample",
        "static_code_analysis.toml",
        "config.yaml",
        PYCACHE,
    )

    # Items to exclude when identifying suite directories
    non_suite_items = (
        ".github",
        "docs",
        PYCACHE,
        "__init__.py",
        "common",
        "pages",
        "resources",
        "utils",
        "conftest.py",
        "README.md",
        "RELEASE_NOTES.md",
        ".env_sample",
        "static_code_analysis.toml",
        "config.yaml",
        "config",
        "test_data_common",
        "test_data",
        "tests",
    )

    # Discover suite directories from template (directories that are not special folders)
    suite_names = []
    for item in template_app_path.iterdir():
        if (
            item.is_dir()
            and item.name not in non_suite_items
            and not item.name.startswith(".")
        ):
            suite_names.append(item.name)

    if suite_names:
        logger.info(f"Discovered suite(s) in template: {', '.join(suite_names)}")
    else:
        logger.warning("No suite directories found in template")

    # --- Copy and Rename Template Content ---
    for item in template_app_path.iterdir():
        if item.name == PYCACHE:
            continue

        # Skip .github, docs, and common files - they'll be copied from common_files
        if item.name in skip_items_for_copying:
            continue

        src = item
        dest = output_dir / item.name
        _copy_item(src, dest)
        if item.is_dir():
            logger.info(f"Copied directory: {dest}")

    # --- Copy Common Files ---
    common_files_dir = current_dir / RESOURCES_DIR_NAME / COMMON_FILES_DIR_NAME
    first_suite = suite_names[0] if suite_names else ""
    placeholder_replacements = {"app_name": app_name, "suite": first_suite}

    if common_files_dir.exists():

        _copy_and_replace_placeholders_in_dir(
            common_files_dir / "docs", root_dir / "docs", placeholder_replacements
        )
        _copy_common_file(
            common_files_dir, root_dir, "README.md", placeholder_replacements
        )
        _copy_common_file(
            common_files_dir, root_dir, "RELEASE_NOTES.md", placeholder_replacements
        )
        _copy_common_file(
            common_files_dir, root_dir, ".env_sample", placeholder_replacements
        )

        if not (output_dir / "config").is_dir():
            _copy_common_file(
                common_files_dir, output_dir, "config.yaml", placeholder_replacements
            )

        _copy_common_file(
            common_files_dir, root_dir, "pytest.ini", placeholder_replacements
        )
        _copy_common_file(
            common_files_dir, root_dir, ".gitignore", placeholder_replacements
        )

    else:
        logger.warning(f"Common files directory not found at {common_files_dir}")


# --- Update References and Placeholders ---
    logger.debug(
        f"Updating file references from '{scaffold_template}' to '{app_name}'..."
    )

    # Update complex references in all created suites
    for suite_name in suite_names:
        suite_dir = output_dir / suite_name
        if not suite_dir.is_dir():
            continue

        # Replace references for this specific suite (using the actual suite name from template).
        # Also replace the base template name (TEMPLATE_APP_NAME = "saucedemo") which may appear
        # in imports inside saucedemoapp template files independently of the folder name.
        all_template_names = list(dict.fromkeys([scaffold_template, TEMPLATE_APP_NAME]))
        reference_replacements = {}
        for tmpl in all_template_names:
            reference_replacements.update({
                rf"\bapps\.{re.escape(tmpl)}\.{re.escape(suite_name)}\b": f"apps.{app_name}.{suite_name}",
                rf"\bapps/{re.escape(tmpl)}/{re.escape(suite_name)}\b": f"apps/{app_name}/{suite_name}",
                rf"\bapps\.{re.escape(tmpl)}\b": f"apps.{app_name}",
                rf"\bfrom {re.escape(tmpl)}\.": f"from {app_name}.",
                rf"\bimport {re.escape(tmpl)}\.": f"import {app_name}.",
            })
        for path in suite_dir.rglob("*"):
            if path.is_file():
                _replace_references_in_file(path, reference_replacements)

    # Replace references in ALL files under output_dir (pages/, tests/, conftest.py, etc.)
    # The suite loop above only covers suite subdirectories — templates like saucedemo
    # have tests/ and pages/ in non_suite_items, so imports like
    # "from apps.saucedemo.pages..." are never updated, causing ImportError at collection.
    all_template_names = list(dict.fromkeys([scaffold_template, TEMPLATE_APP_NAME]))
    full_replacements = {}
    for tmpl in all_template_names:
        full_replacements.update({
            rf"\bapps\.{re.escape(tmpl)}\b": f"apps.{app_name}",
            rf"\bapps/{re.escape(tmpl)}\b": f"apps/{app_name}",
            rf"\bfrom {re.escape(tmpl)}\.": f"from {app_name}.",
            rf"\bimport {re.escape(tmpl)}\.": f"import {app_name}.",
        })
    for path in output_dir.rglob("*"):
        if path.is_file():
            _replace_references_in_file(path, full_replacements)

    logger.info(f"Successfully created project structure at: {output_dir}")
    return output_dir

def setup_pipeline_files(root_dir: Path):
    """
    Copies pipeline-related files from common_files to the root directory.

    Args:
        root_dir: The root directory of the project.
    """
    current_dir = Path(__file__).parent
    common_files_dir = current_dir / RESOURCES_DIR_NAME / COMMON_FILES_DIR_NAME

    if not common_files_dir.exists():
        logger.error(f"Common files directory not found at {common_files_dir}")
        return

    placeholder_replacements = {} # No app-specific placeholders needed for these root files generally

    logger.info("Setting up pipeline files...")

    # .github and docs folders
    _copy_and_replace_placeholders_in_dir(
        common_files_dir / ".github", root_dir / ".github", placeholder_replacements
    )
    _copy_and_replace_placeholders_in_dir(
        common_files_dir / "docs", root_dir / "docs", placeholder_replacements
    )

    # Root level pipeline files
    _copy_common_file(
        common_files_dir, root_dir, "static_code_analysis.toml", placeholder_replacements
    )
    _copy_common_file(
        common_files_dir, root_dir, "requirements.txt", placeholder_replacements
    )
    _copy_common_file(
        common_files_dir,
        root_dir,
        "requirements-sca-pipeline.txt",
        placeholder_replacements,
    )

    logger.info("Successfully set up pipeline files.")



def create_scaffold_from_simple_template(app_name: str):
    """
    Creates a project structure from a simple template.
    Automatically discovers and copies all suite directories from the template.

    Args:
        app_name: Name for the application folder.
    """
    logger.info(f"Creating project from simple template for app '{app_name}'")
    current_dir = Path(__file__).parent
    template_dir = current_dir / RESOURCES_DIR_NAME / TEMPLATE_DIR_NAME
    if not template_dir.exists():
        logger.error(f"Template directory not found at {template_dir}")
        sys.exit(1)

    output_dir = Path.cwd() / APPS_DIR_NAME / app_name
    root_dir = Path.cwd()
    apps_dir = Path.cwd() / APPS_DIR_NAME
    if output_dir.exists():
        logger.error(f"Directory '{app_name}' already exists")
        sys.exit(1)

    output_dir.mkdir(parents=True)

    # Create __init__.py in apps directory if it doesn't exist
    apps_init_file = apps_dir / "__init__.py"
    if not apps_init_file.exists():
        apps_init_file.touch()
        logger.info(f"Created {apps_init_file}")

    # Discover suite directories from template
    template_app_dir = template_dir / "app-name"
    suite_names = []
    if template_app_dir.exists():
        for item in template_app_dir.iterdir():
            if item.is_dir() and not item.name.startswith("_") and item.name != PYCACHE:
                suite_names.append(item.name)

    if suite_names:
        logger.info(f"Discovered suite(s) in template: {', '.join(suite_names)}")
    else:
        logger.warning(
            "No suite directories found in template, will use default 'suite' name"
        )
        suite_names = ["suite"]

    # --- Copy Common Files ---
    common_files_dir = current_dir / RESOURCES_DIR_NAME / COMMON_FILES_DIR_NAME
    first_suite = suite_names[0] if suite_names else ""
    placeholder_replacements = {"app_name": app_name, "suite": first_suite}

    if common_files_dir.exists():

        _copy_and_replace_placeholders_in_dir(
            common_files_dir / "docs", root_dir / "docs", placeholder_replacements
        )
        _copy_common_file(
            common_files_dir, root_dir, "README.md", placeholder_replacements
        )
        _copy_common_file(
            common_files_dir, root_dir, "RELEASE_NOTES.md", placeholder_replacements
        )
        _copy_common_file(
            common_files_dir, root_dir, ".env_sample", placeholder_replacements
        )

        _copy_common_file(
            common_files_dir, output_dir, "config.yaml", placeholder_replacements
        )

        _copy_common_file(
            common_files_dir, root_dir, "pytest.ini", placeholder_replacements
        )
        _copy_common_file(
            common_files_dir, root_dir, ".gitignore", placeholder_replacements
        )

    else:
        logger.warning(f"Common files directory not found at {common_files_dir}")

    # --- Create Suite Directories ---
    for suite in suite_names:
        template_suite = template_app_dir / suite if template_app_dir.exists() else None
        suite_dir = output_dir / suite

        if template_suite and template_suite.exists():
            # Copy the entire suite directory from template
            _copy_item(template_suite, suite_dir)
            logger.info(f"Copied suite directory: {suite}")
            # Replace placeholders in copied files
            for file_path in suite_dir.rglob("*"):
                if file_path.is_file():
                    suite_replacements = {"app_name": app_name, "suite": suite}
                    _replace_placeholders_in_file(file_path, suite_replacements)
        else:
            # Create empty suite directory if template doesn't exist
            suite_dir.mkdir(parents=True, exist_ok=True)
            logger.info(f"Created empty suite directory: {suite}")

    logger.info(f"Successfully created project structure at: {output_dir}")
    return output_dir


def create_scaffold(app_name: str, scaffold_template: str = None):
    """
    Main entry point to create a project structure from a template.
    Automatically discovers and copies suite directories from the chosen template.

    Args:
        app_name: Name for the application folder.
        scaffold_template: Template to use:
                           - None / 'false': minimal template (simple placeholder tests)
                           - 'true': basic saucedemo scaffold (limited test cases)
                           - 'full': full saucedemoapp template (all test suites)
    """
    if not scaffold_template or scaffold_template.lower() in ("false", "0", "no"):
        return create_scaffold_from_simple_template(app_name)
    elif scaffold_template.lower() == "full":
        return create_scaffold_from_template_app(app_name, "saucedemoapp")
    elif scaffold_template.lower() in ("true", "1", "yes"):
        return create_scaffold_from_template_app(app_name, TEMPLATE_APP_NAME)
    else:
        return create_scaffold_from_template_app(app_name, scaffold_template)
