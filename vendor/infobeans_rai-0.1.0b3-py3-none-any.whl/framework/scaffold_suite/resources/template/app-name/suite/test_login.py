# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import requests

BASE_URL = "https://jsonplaceholder.typicode.com"


# @pytest.mark.xray(<Project-Key>-<Test-Issue-ID>)
def test_get_posts_status_code():
    """
    Verify GET /posts returns HTTP 200
    """
    response = requests.get(f"{BASE_URL}/posts")
    assert response.status_code == 200


# @pytest.mark.xray(<Project-Key>-<Test-Issue-ID>)
def test_get_posts_response_is_list():
    """
    Verify response body is a list
    """
    response = requests.get(f"{BASE_URL}/posts")
    assert isinstance(response.json(), list)


# @pytest.mark.xray(<Project-Key>-<Test-Issue-ID>)
def test_get_single_post_by_id():
    """
    Verify GET /posts/1 returns correct post data
    """
    response = requests.get(f"{BASE_URL}/posts/1")
    body = response.json()

    assert response.status_code == 200
    assert body["id"] == 1
    assert "title" in body
    assert "body" in body


# @pytest.mark.xray(<Project-Key>-<Test-Issue-ID>)
def test_invalid_post_returns_404():
    """
    Verify invalid resource returns 404
    """
    response = requests.get(f"{BASE_URL}/posts/999999")
    assert response.status_code == 404
