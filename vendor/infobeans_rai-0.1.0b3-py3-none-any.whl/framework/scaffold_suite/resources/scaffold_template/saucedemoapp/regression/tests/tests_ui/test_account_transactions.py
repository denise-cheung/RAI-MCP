# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.
import random

import allure
import pytest

@allure.parent_suite("Account Transaction - UI")            
# @allure.suite("Account Transaction")
# @allure.epic("Home Page")
@allure.epic("Account Transactions")
class TestCurrentAndSavingsAccountsTransactions:
    """Contains all test cases for the Current and Savings Accounts Transactions module."""

    @pytest.mark.xray("MYY-78")
    @allure.feature("Account Transactions")
    @allure.tag("smoke", "regression","MYY-78")
    @allure.story("Verify Money Transfer")
    @allure.title("MYY-78: Verify that money transfer between own accounts works correctly.")
    @allure.description("Verify that money transfer between own accounts works correctly.")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.label("owner", "swapnil")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-78", name="Jira MYY-78")
    def test_verify_money_transfer_between_own_accounts(self):
        """Test money transfer between own accounts."""
        assert random.choice([True, False]), "Random failure: Money transfer"

    @pytest.mark.xray("MYY-46")
    @allure.feature("Account Transactions")
    @allure.tag("smoke", "regression","MYY-46")
    @allure.story("Verify Transaction History")
    @allure.title("MYY-46: Verify that transaction history is accurate.")
    @allure.description("Verify that transaction history is accurate.")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.label("owner", "swapnil")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-46", name="Jira MYY-46")
    def test_check_transaction_history_accuracy(self):
        """Test transaction history accuracy."""
        assert random.randint(1, 10) > 3, "Random failure: Transaction history"

    @pytest.mark.xray("MYY-47")
    @allure.feature("Account Transactions")
    @allure.tag("smoke", "regression","MYY-47")
    @allure.story("Verify Account Balance")
    @allure.title("MYY-47: Verify that account balance is calculated correctly after a transaction.")
    @allure.description("Verify that account balance is calculated correctly after a transaction.")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.label("owner", "swapnil")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-47", name="Jira MYY-47")
    def test_account_balance_after_transaction(self):
        """Test balance calculation after a transaction."""
        initial_balance = 1000
        transaction_amount = 150
        expected_balance = 850
        new_balance = initial_balance - transaction_amount
        assert new_balance == expected_balance, "Balance calculation is incorrect"

    @pytest.mark.xray("MYY-48")
    @allure.feature("Account Transactions")
    @allure.tag("smoke", "regression","MYY-48")
    @allure.story("Verify IMPS Transfer")
    @allure.title("MYY-48: Verify that IMPS transfer functionality works correctly.")
    @allure.description("Verify that IMPS transfer functionality works correctly.")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.label("owner", "swapnil")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-48", name="Jira MYY-48")
    def test_imps_transfer_functionality(self):
        """Test IMPS transfer functionality."""
        assert random.choice([True, False]), "Random failure: IMPS transfer"

    @pytest.mark.xray("MYY-49")
    @allure.feature("Account Transactions")
    @allure.tag("smoke", "regression","MYY-49")
    @allure.story("Verify Withdrawal Limit Enforcement")
    @allure.title("MYY-49: Verify that withdrawal limit enforcement works correctly.")
    @allure.description("Verify that withdrawal limit enforcement works correctly.")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.label("owner", "swapnil")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-49", name="Jira MYY-49")
    def test_check_withdrawal_limit_enforcement(self):
        """Test withdrawal limit enforcement."""
        daily_limit = 10000
        withdrawal_amount = 5000
        assert withdrawal_amount <= daily_limit, "Withdrawal should be within the daily limit"

    @pytest.mark.xray("MYY-50")
    @allure.feature("Account Transactions")
    @allure.tag("smoke", "regression","MYY-50")
    @allure.story("Verify Deposit Transaction Logging")
    @allure.title("MYY-50: Verify that deposit transaction logging works correctly.")
    @allure.description("Verify that deposit transaction logging works correctly.")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.label("owner", "swapnil")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-50", name="Jira MYY-50")
    def test_deposit_transaction_logging(self):
        """Test deposit transaction logging."""
        assert random.randint(0, 1) == 1, "Random failure: Deposit logging"

    @pytest.mark.xray("MYY-51")
    @allure.feature("Account Transactions")
    @allure.tag("smoke", "regression")
    @allure.story("Verify Mini Statement Generation")
    @allure.title("MYY-51: Verify that mini statement generation works correctly.")
    @allure.description("Verify that mini statement generation works correctly.")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.label("owner", "swapnil")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-51", name="Jira MYY-51")
    def test_verify_mini_statement_generation(self):
        """Test mini statement generation."""
        assert "success" in random.choice(["success", "failed"]), "Random failure: Mini statement"

    @pytest.mark.xray("MYY-52")
    @allure.feature("Account Transactions")
    @allure.tag("smoke", "regression","MYY-52")
    @allure.story("Verify Overdraft Limit Warnings")
    @allure.title("MYY-52: Verify that overdraft limit warnings are displayed correctly.")
    @allure.description("Verify that overdraft limit warnings are displayed correctly.")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.label("owner", "swapnil")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-52", name="Jira MYY-52")
    def test_check_overdraft_limit_warnings(self):
        """Test overdraft limit warnings."""
        assert random.choice([True, False]), "Random failure: Overdraft warning"

    @pytest.mark.xray("MYY-53")
    @allure.feature("Account Transactions")
    @allure.tag("smoke", "regression","MYY-53")
    @allure.story("Verify Failed Transaction Due to Downtime")
    @allure.title("MYY-53: Verify that failed transaction due to downtime is handled correctly.")
    @allure.description("Verify that failed transaction due to downtime is handled correctly.")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.label("owner", "swapnil")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-53", name="Jira MYY-53")
    def test_failed_transaction_due_to_downtime(self):
        """Test failed transaction due to downtime."""
        assert random.randint(1, 5) != 1, "Random failure: Failed transaction"
