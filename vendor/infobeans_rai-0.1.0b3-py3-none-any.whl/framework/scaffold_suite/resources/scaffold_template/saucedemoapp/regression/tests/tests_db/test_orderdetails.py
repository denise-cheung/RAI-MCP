# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.
import allure
import pytest

from apps.saucedemoapp.regression.base.base_db import BaseDB

@allure.parent_suite("Order Details - DB") 
@pytest.mark.usefixtures("db", "get_db_test_data")
class TestOrderDetailsData:
    db = None

    @pytest.fixture(autouse=True)
    def setup_method(self, db: BaseDB):
        """
        Setup the test environment.
        """
        self.db = db

    @pytest.mark.skip("skipped to avoid data storage on DB")
    def test_insert_orderdetails(self, get_db_test_data_dict):

        orderdetails = get_db_test_data_dict["orderdetails"]
        for od in orderdetails:
            query = f"""
            INSERT INTO orderdetails (orderNumber, productCode, quantityOrdered, priceEach, orderLineNumber)
            VALUES ({od['orderNumber']}, '{od['productCode']}', {od['quantityOrdered']}, {od['priceEach']}, {od['orderLineNumber']});
            """
            self.db.cursor.execute(query)
        self.db.connection.commit()

    def test_orderdetails_aggregate(self):
        query = "SELECT SUM(quantityOrdered*priceEach) FROM orderdetails;"
        result = self.db.execute_query(query)
        assert result[0][0] > 0

    def test_orderdetails_group_by_product(self):
        query = """
        SELECT productCode, SUM(quantityOrdered) AS total_qty
        FROM orderdetails
        GROUP BY productCode
        ORDER BY total_qty DESC;
        """
        results = self.db.execute_query(query)
        assert len(results) > 0
