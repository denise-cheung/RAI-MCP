import os
import time
from pathlib import Path

import pytest

from apps.saucedemoapp.regression.helpers.home_helper import HomePageHelper
from apps.saucedemoapp.regression.helpers.login_helper import LoginHelper
from apps.saucedemoapp.regression.helpers.order_helper import OrderHelper
from framework.core.utils.logger import get_logger

logger = get_logger()


@pytest.mark.usefixtures("page")
class BaseTest:
    login_helper = None
    home_helper = None
    order_helper = None

    def setup_method(self, page):
        logger.debug("Setting up test base helpers")
        # Expose page on the test instance for tests that use self.page
        self.page = page
        if self.page is None:
            logger.error("Page fixture returned None; browser failed to start.")
            raise RuntimeError("Playwright page fixture is None. Check browser/setup.")

        base_url = os.getenv("BASE_URL", "https://www.saucedemo.com/")
        try:
            logger.info(f"Navigating to BASE_URL: {base_url}")
            self.page.goto(base_url)
            # Quick sanity check: ensure login page loaded by waiting for username input
            try:
                self.page.wait_for_selector('input[name="user-name"]', timeout=3000)
                logger.info("Login page appears to have loaded (username input found)")
            except Exception as wait_err:
                logger.warning(
                    f"Login page did not load within timeout: {wait_err} | page_url={getattr(self.page, 'url', 'unknown')}"
                )
                # Save a DOM snapshot for debugging
                try:
                    ts = time.strftime("%Y%m%d-%H%M%S")
                    reports_dir = Path(os.getenv("REPORT_ROOT", "reports"))
                    reports_dir.mkdir(parents=True, exist_ok=True)
                    snap_file = reports_dir / f"navigation_dom_{ts}.html"
                    content = self.page.content() if hasattr(self.page, "content") else ""
                    with open(snap_file, "w", encoding="utf-8") as f:
                        f.write(content)
                    logger.info(f"Saved navigation DOM snapshot: {snap_file}")
                except Exception as snap_err:
                    logger.debug(f"Failed to save navigation DOM snapshot: {snap_err}")
        except Exception as e:
            logger.warning(f"Failed to navigate to BASE_URL: {e}")
            # Leave page as-is (tests may navigate explicitly)

        self.login_helper = LoginHelper(self.page)
        self.home_helper = HomePageHelper(self.page)
        self.order_helper = OrderHelper(self.page)
        logger.debug("Test base setup completed")
