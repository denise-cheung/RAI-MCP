# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

from types import SimpleNamespace

import allure
import pytest

from apps.saucedemoapp.regression.base.testbase import BaseTest
from apps.saucedemoapp.regression.utils.logger import get_logger
from apps.saucedemoapp.regression.utils.test_metadata import annotate_test_metadata
from apps.saucedemoapp.test_data_common.test_data import test_data
from framework.browser.browser_factory import BrowserFactory

logger = get_logger()

@allure.parent_suite("Home Page - UI")            
# @allure.suite("Home Page")
@allure.epic("Home Page")

# @allure.epic("SwagLabs Features")
# @allure.feature("Home Page")
@pytest.mark.usefixtures("page")
class TestHomePage(BaseTest):
    page: None

    @pytest.fixture(autouse=True)
    def set_page(self, page):
        """Set the page instance for the test."""
        self.page = page

    @pytest.fixture(autouse=True)
    def setup_method(self):
        """Set up the test environment."""
        super().setup_method(self.page)
        logger.info("Setting up HomePage tests...")
        self.login_helper.login(
            test_data["login"]["valid_credentials"]["username"],
            test_data["login"]["valid_credentials"]["password"],
        )
        logger.info("Login attempted with valid credentials.")

    @annotate_test_metadata
    @pytest.mark.smoke
    @pytest.mark.xray("MYY-4")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-4", name="MYY-4")
    @allure.story("Product Listing")
    @allure.title("Display product list on the home page after login")
    @allure.tag("ui", "smoke", "regression","MYY-4")
    @allure.label("owner", "swapnil")
    @pytest.mark.dependency(depends=["test_sorting_options"])
    def test_products_displayed(self):
        assert (
            self.home_helper.verify_products_displayed()
        ), "No products displayed on the home page."

    @annotate_test_metadata
    @pytest.mark.xray("MYY-5")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-5", name="MYY-5")
    @allure.story("Sorting")
    @allure.title("Show sorting options on the home page")
    @allure.tag("ui", "regression","MYY-5")
    @allure.label("owner", "swapnil")
    def test_sorting_options(self):
        assert (
            self.home_helper.verify_sorting_options_available()
        ), "Sorting options are not available or insufficient."

    @annotate_test_metadata
    @pytest.mark.xray("MYY-5")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-5", name="MYY-5")
    @allure.story("Footer Links")
    @allure.title("Display social media links on the home page")
    @allure.tag("ui", "regression","MYY-5")
    @allure.label("owner", "swapnil")
    def test_social_media_links(self):
        assert (
            self.home_helper.verify_social_media_links()
        ), "Social media links are not present on the home page."

    @annotate_test_metadata
    @pytest.mark.xray("MYY-6")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-6", name="MYY-6")
    @allure.story("Navigation Menu")
    @allure.title("Navigate through menu options successfully")
    @allure.tag("ui", "regression","MYY-6")
    @allure.label("owner", "swapnil")
    def test_displayed_menu(self):
        assert (
            self.home_helper.verify_menus()
        ), "Menu navigation is not functioning as expected."

    @annotate_test_metadata
    @pytest.mark.xray("MYY-8")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-8", name="MYY-8")
    @allure.story("Product Details")
    @allure.title("Display correct product details on the home page")
    @allure.tag("ui", "regression","MYY-8")
    @allure.label("owner", "swapnil")
    def test_product_details(self):
        assert (
            self.home_helper.verify_product_details()
        ), "Product details are not displayed correctly."
