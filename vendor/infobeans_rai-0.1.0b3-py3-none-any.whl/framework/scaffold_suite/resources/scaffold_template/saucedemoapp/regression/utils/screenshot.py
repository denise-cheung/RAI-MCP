import os
from datetime import datetime

SCREENSHOT_DIR = "artifacts/screenshots"
os.makedirs(SCREENSHOT_DIR, exist_ok=True)

def capture_screenshot(driver, test_name):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = f"{SCREENSHOT_DIR}/{test_name}_{timestamp}.png"
    driver.save_screenshot(path)
    return path