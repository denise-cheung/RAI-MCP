# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import random
import pytest
import allure

from apps.saucedemoapp.regression.utils.retry_utils import retry
from apps.saucedemoapp.regression.utils.test_metadata import annotate_test_metadata

@allure.parent_suite("Payment Flow with Card Details - UI")            
# @allure.suite("Payment Flow")
# @allure.epic("Home Page")
@allure.epic("Payments")
@allure.feature("Payment Processing")
class TestPaymentFlowOnUI:
    """Contains all test cases for the Payment Flow UI module."""

    @annotate_test_metadata
    @pytest.mark.xray("MYY-16")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-16", name="MYY-16")
    @allure.story("Card Payment")
    @allure.title("User completes payment successfully using a valid card")
    @allure.tag("ui", "payment", "smoke", "regression","MYY-16")
    def test_verify_successful_payment_with_valid_card_details(self):
        with allure.step("Enter valid card details"):
            pass

        with allure.step("Submit payment"):
            pass

        with allure.step("Verify payment success message"):
            assert random.choice([True, False]), "Payment should be successful"

    @annotate_test_metadata
    @pytest.mark.xray("MYY-17")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-17", name="MYY-17")
    @allure.story("Card Validation")
    @allure.title("Error is shown when user enters an expired card")
    @allure.tag("ui", "payment", "negative", "regression","MYY-17")
    def test_validate_error_on_expired_card_entry(self):
        with allure.step("Enter expired card details"):
            pass

        with allure.step("Attempt payment"):
            pass

        with allure.step("Verify expired card error message"):
            assert random.randint(1, 10) > 3, "Expired card error should be displayed"

    @annotate_test_metadata
    @pytest.mark.xray("MYY-18")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-18", name="MYY-18")
    @allure.story("Card Validation")
    @allure.title("Payment is declined when invalid card details are used")
    @allure.tag("ui", "payment", "negative", "MYY-18")
    def test_validate_error_on_invalid_card_entry(self):
        with allure.step("Enter invalid card details"):
            pass

        with allure.step("Verify payment is declined"):
            assert "success" not in random.choice(
                ["success", "decline", "error"]
            ), "Payment should not be successful"

    @annotate_test_metadata
    @pytest.mark.xray("MYY-19")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-19", name="MYY-19")
    @allure.story("Card Validation")
    @allure.story("Security Validation")
    @allure.title("CVV field accepts only 3-digit numeric values")
    @allure.tag("ui", "payment", "security", "MYY-19")
    def test_validate_cvv_check_during_payment(self):
        with allure.step("Enter CVV"):
            cvv = "123"

        with allure.step("Validate CVV format"):
            assert len(cvv) == 3, "CVV should be 3 digits"
            assert cvv.isdigit(), "CVV should contain only numbers"

    @annotate_test_metadata
    @pytest.mark.xray("MYY-20")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-20", name="MYY-20")
    @allure.story("Currency Handling")
    @allure.title("Payment amount updates correctly when currency is changed")
    @allure.tag("ui", "payment", "regression","MYY-20")
    def test_verify_currency_change_updates_payment_amount(self):
        with allure.step("Change payment currency"):
            pass

        with allure.step("Verify updated payment amount"):
            assert 100 * 1.1 == random.choice([110, 110.0, 111]), \
                "Payment amount should update based on currency"

    @pytest.mark.skip("Skipping UPI payment integration test")
    @allure.story("UPI Payment")
    @allure.title("User completes payment using UPI")
    def test_upi_payment_integration_flow(self):
        assert random.choice([True, False])

    @annotate_test_metadata
    @pytest.mark.xray("MYY-22")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-22", name="MYY-22")
    @allure.story("Saved Cards")
    @allure.title("Saved card details are auto-filled during payment")
    @allure.tag("ui", "payment", "usability","MYY-22")
    def test_validate_saved_card_autofill_functionality(self):
        with allure.step("Select saved card"):
            pass

        with allure.step("Verify card details are auto-filled"):
            assert random.randint(0, 1) == 1, "Saved card should auto-fill"

    @annotate_test_metadata
    @retry(max_attempts=3, delay=1)
    @pytest.mark.xray("MYY-23")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-23", name="MYY-23")
    @allure.story("Payment Confirmation")
    @allure.title("Success message is displayed after a successful transaction")
    @allure.tag("ui", "payment", "smoke","MYY-23")
    def test_verify_success_message_post_successful_transaction(self):
        with allure.step("Complete payment"):
            pass

        with allure.step("Verify success confirmation message"):
            assert "Success" in random.choice(
                ["Payment Success", "Payment Failed"]
            )

    @annotate_test_metadata
    @pytest.mark.xray("MYY-25")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-25", name="MYY-25")
    @retry(max_attempts=3, delay=1)
    @allure.story("Discounts & Offers")
    @allure.title("Promo code discount is applied correctly during payment")
    @allure.tag("ui", "payment", "regression","MYY-25")
    def test_check_promo_code_application_in_payment(self):
        with allure.step("Apply promo code"):
            price = 100
            discount = 10

        with allure.step("Verify discounted amount"):
            final_price = price - discount
            assert final_price == 90, "Promo code discount should be applied correctly"

    @annotate_test_metadata
    @pytest.mark.xray("MYY-29")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-29", name="MYY-29")
    @allure.story("Payment Summary")
    @allure.title("Payment breakdown displays correct tax and discount values")
    @allure.tag("ui", "payment", "regression","MYY-29")
    def test_validate_payment_breakdown_with_tax_and_discount(self):
        with allure.step("Review payment breakdown"):
            pass

        with allure.step("Verify tax and discount calculation"):
            assert 100 + 10 - 5 == random.choice([105, 104])
