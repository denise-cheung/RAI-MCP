# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.

# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.

# This package is intended for internal enterprise use only.

import os
from pathlib import Path

import allure
import pytest

from apps.saucedemoapp import __path__ as app_path
from apps.saucedemoapp.regression.base.testbase import BaseTest
from apps.saucedemoapp.regression.utils.file_op_utils import read_csv

base_url = os.getenv("BASE_URL", "https://www.saucedemo.com/")
csv_path = Path(app_path[0]) / "test_data_common" / "login_creds_data.csv"

@allure.parent_suite("Login Parameters - UI")            
# @allure.suite("Login Parameterized")
# @allure.epic("Home Page")
@allure.epic("Authentication")
@allure.feature("Login")
@pytest.mark.usefixtures("page")
class TestLoginParameterized(BaseTest):
    page: None

    @pytest.fixture(autouse=True)
    def setup_method(self, page):
        """Setup the test environment."""
        super().setup_method(page)

    @pytest.mark.parametrize(
        "username,password,is_valid_user,expected_result",
        [tuple(data.values()) for data in read_csv(csv_path)],
    )
    @allure.story("Login with multiple credential combinations")
    @allure.tag("ui", "login", "regression", "parameterized")
    def test_parameterized_valid_login(
        self, username, password, is_valid_user, expected_result
    ):
        """
        Verify login behavior using valid and invalid credentials from CSV.
        """

        # 👉 Dynamic, user-friendly title per test iteration
        allure.dynamic.title(
            f"Login with user '{username}' → Expected result: {expected_result}"
        )

        self.login_helper.login(username, password)

        # Convert string to boolean for is_valid_user
        is_valid = (
            is_valid_user.lower() == "true"
            if isinstance(is_valid_user, str)
            else is_valid_user
        )

        if is_valid and expected_result == "Success":
            with allure.step("Verify successful login redirects to inventory page"):
                expected_url = f"{base_url}inventory.html"
                page_url = self.login_helper.get_current_url()
                assert page_url == expected_url
        else:
            with allure.step("Verify login error message is displayed"):
                if username == "locked_out_user":
                    self.login_helper.verify_login_error(
                        "Epic sadface: Sorry, this user has been locked out."
                    )
