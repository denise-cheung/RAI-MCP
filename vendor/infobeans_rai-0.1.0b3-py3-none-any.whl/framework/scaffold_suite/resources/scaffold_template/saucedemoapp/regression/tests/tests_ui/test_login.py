# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import os

import allure
import pytest

from apps.saucedemoapp.regression.base.testbase import BaseTest
from apps.saucedemoapp.regression.utils.retry_utils import retry
from apps.saucedemoapp.regression.utils.test_metadata import annotate_test_metadata
from apps.saucedemoapp.test_data_common.test_data import test_data

base_url = os.getenv("BASE_URL", "https://www.saucedemo.com/")

@allure.parent_suite("Account Login - UI")            
# @allure.suite("Login Page")
# @allure.epic("Home Page")
@allure.epic("Authentication")
@allure.feature("Login")
@pytest.mark.usefixtures("page")
class TestLogin(BaseTest):
    page = None

    @pytest.fixture(autouse=True)
    def setup_method(self, page):
        """Setup the test environment."""
        super().setup_method(page)

    @annotate_test_metadata
    @pytest.mark.xray("MYY-9")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-9", name="MYY-9")
    @allure.story("Valid Login")
    @allure.title("Login successfully with valid credentials")
    @allure.tag("ui", "login", "smoke", "regression", "MYY-9")
    def test_valid_login(self):
        self.login_helper.login(
            test_data["login"]["valid_credentials"]["username"],
            test_data["login"]["valid_credentials"]["password"],
        )
        self.login_helper.verify_login_success(base_url + "inventory.html")

    @annotate_test_metadata
    @pytest.mark.xray("MYY-14")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-14", name="MYY-14")
    @retry(max_attempts=3, delay=1)
    @allure.story("Logout")
    @allure.title("Logout successfully after valid login")
    @allure.tag("ui", "login", "regression", "MYY-14")
    def test_logout(self):
        self.login_helper.login(
            test_data["login"]["valid_credentials"]["username"],
            test_data["login"]["valid_credentials"]["password"],
        )
        self.login_helper.logout()
        self.login_helper.verify_logout_success(base_url + "/index.html")

    @annotate_test_metadata
    @pytest.mark.xray("MYY-13")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-13", name="MYY-13")
    @allure.story("Post Login Validation")
    @allure.title("Verify page title after successful login")
    @allure.tag("ui", "login", "regression")
    def test_page_title(self):
        self.login_helper.login(
            test_data["login"]["valid_credentials"]["username"],
            test_data["login"]["valid_credentials"]["password"],
        )
        self.login_helper.verify_page_title("Swag Labs")

    @annotate_test_metadata
    @pytest.mark.xray("MYY-10")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-10", name="MYY-10")
    @pytest.mark.slow
    @allure.story("Login Page UI Validation")
    @allure.title("Verify login page UI elements are displayed")
    @allure.tag("ui", "login", "regression", "slow", "MYY-10")
    def test_login_page_elements(self):
        self.page.goto(base_url)
        assert self.page.is_visible('input[name="user-name"]')
        assert self.page.is_visible('input[name="password"]')
        assert self.page.is_visible('input[type="submit"]')

    @annotate_test_metadata
    @pytest.mark.xray("MYY-11")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-11", name="MYY-11")
    @allure.story("Invalid Login")
    @allure.title("Show error message for invalid login credentials")
    @allure.tag("ui", "login", "negative", "regression", "MYY-11")
    def test_invalid_login(self):
        self.login_helper.login(
            test_data["login"]["invalid_credentials"]["username"],
            test_data["login"]["invalid_credentials"]["password"],
        )
        self.login_helper.verify_login_error(
            "Epic sadface: Sorry, this user has been locked out"
        )

    @annotate_test_metadata
    @pytest.mark.xray("MYY-12")
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-12", name="MYY-12")
    @allure.story("Problem User Login")
    @allure.title("Login successfully using problem user credentials")
    @allure.tag("ui", "login", "regression")
    def test_problem_user_login(self):
        self.login_helper.login(
            test_data["login"]["problem_user"]["username"],
            test_data["login"]["problem_user"]["password"],
        )
        self.login_helper.verify_login_success(base_url + "inventory.html")
