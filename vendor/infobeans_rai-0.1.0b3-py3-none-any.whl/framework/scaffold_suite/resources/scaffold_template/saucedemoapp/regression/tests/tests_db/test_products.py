# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.
import allure
import pytest

from apps.saucedemoapp.regression.base.base_db import BaseDB
from apps.saucedemoapp.regression.utils.faker_singleton import FakerSingleton

faker = FakerSingleton()
random_id = faker.random_int()
random_float = faker.random_float()

@allure.parent_suite("Products - DB") 
@pytest.mark.usefixtures("db", "get_db_test_data")
class TestProductsData:
    db = None

    @pytest.fixture(autouse=True)
    def setup_method(self, db: BaseDB):
        """
        Setup the test environment.
        """
        self.db = db

    def test_insert_products(self, get_db_test_data):
        products = get_db_test_data["products"]["records"]
        for p in products:
            random_number = f"{random_id}{p[0]}"
            query = f"""
            INSERT INTO products (productCode, productName, productLine, productScale, productVendor, productDescription, quantityInStock, buyPrice, MSRP)
            VALUES ('{random_number}', '{p[1]}', '{p[2]}', '{p[3]}', '{p[4]}', '{p[5]}', {p[6]}, {p[7]}, {random_float});
            """
            self.db.execute_query(query)
        self.db.connection.commit()
        for p in products:
            random_number = f"{random_id}{p[0]}"
            query = f"SELECT * FROM products WHERE productCode = '{random_number}';"
            result = self.db.execute_query(query)
            assert len(result) == 1

    def test_select_products(self):
        results = self.db.execute_query("SELECT productName, quantityInStock FROM products;")
        assert len(results) > 0

    def test_product_stock_update(self, get_db_test_data):
        first_product = get_db_test_data["products"]["records"][0]
        self.db.execute_query(
            f"UPDATE products SET quantityInStock=quantityInStock+10 WHERE productCode='{random_id}{first_product[0]}';"
        )
        self.db.connection.commit()
        result = self.db.execute_query(
            f"SELECT quantityInStock FROM products WHERE productCode='{random_id}{first_product[0]}' and quantityInStock >= 10;"
        )
        assert result[0][0] >= 10

    def test_delete_stock_update(self, get_db_test_data):
        first_product = get_db_test_data["products"]["records"][0]
        self.db.execute_query(f"DELETE FROM products WHERE productCode='{random_id}{first_product[0]}';")
        self.db.connection.commit()
        result = self.db.execute_query(
            f"SELECT quantityInStock FROM products WHERE productCode='{random_id}{first_product[0]}';"
        )
        assert result == []

    def test_product_aggregate_price(self):
        result = self.db.execute_query("SELECT AVG(buyPrice) FROM products;")
        assert result[0][0] > 0
