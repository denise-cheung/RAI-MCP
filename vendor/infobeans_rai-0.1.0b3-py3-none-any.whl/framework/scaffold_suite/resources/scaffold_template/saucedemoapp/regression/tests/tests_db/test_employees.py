# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import allure
import pytest

from apps.saucedemoapp.regression.base.base_db import BaseDB
from apps.saucedemoapp.regression.utils.faker_singleton import FakerSingleton

faker = FakerSingleton()
random_id = faker.random_int()

@allure.parent_suite("Employees Data -DB") 
@pytest.mark.usefixtures("db", "get_db_test_data_dict")
class TestEmployeesData:
    db = None

    @pytest.fixture(autouse=True)
    def setup_method(self, db: BaseDB):
        """
        Setup the test environment.
        """
        self.db = db

    def test_insert_employees(self, get_db_test_data_dict):
        employees = get_db_test_data_dict["employees"]
        for emp in employees:
            random_number = f'{random_id}{emp["employeeNumber"]}'
            query = f"""
            INSERT INTO employees (employeeNumber, lastName, firstName, extension, email, reportsTo, jobTitle, officeCode)
            VALUES ({random_number}, '{emp['lastName']}', '{emp['firstName']}', '{emp['extension']}', '{emp['email']}', {emp['reportsTo'] if emp['reportsTo'] else 'NULL'}, '{emp['jobTitle']}', '2');
            """
            self.db.execute_query(query)
        # verify the records are inserted
        for emp in employees:
            random_number = f'{random_id}{emp["employeeNumber"]}'
            query = f"SELECT * FROM employees WHERE employeeNumber = {random_number};"
            result = self.db.execute_query(query)
            print(result)
            assert len(result) == 1
        self.db.connection.commit()

    def test_update_employees(self, get_db_test_data_dict):
        employees = get_db_test_data_dict["employees"]
        for emp in employees:
            random_number = f'{random_id}{emp["employeeNumber"]}'
            query = f"""
            UPDATE employees
            SET lastName = 'Pinto',
                firstName = 'Maria',
                extension = '1234',
                email = 'maria.pinto@ab.com',
                officeCode = '2'
            WHERE employeeNumber = {random_number};
            """
            self.db.execute_query(query)
        # verify the records are updated
        for emp in employees:
            random_number = f'{random_id}{emp["employeeNumber"]}'
            query = f"SELECT * FROM employees WHERE employeeNumber = {random_number} and lastName = 'Pinto' and firstName = 'Maria' and extension = '1234' and email = 'maria.pinto@ab.com' and officeCode = '2';"
            result = self.db.execute_query(query)
            assert len(result) == 1
        self.db.connection.commit()

    def test_delete_employees(self, get_db_test_data_dict):
        employees = get_db_test_data_dict["employees"]
        for emp in employees:
            random_number = f'{random_id}{emp["employeeNumber"]}'
            query = f"DELETE FROM employees WHERE employeeNumber = {random_number};"
            self.db.execute_query(query)
        # verify the records are deleted
        for emp in employees:
            random_number = f'{random_id}{emp["employeeNumber"]}'
            query = f"SELECT * FROM employees WHERE employeeNumber = {random_number};"
            result = self.db.execute_query(query)
            assert len(result) == 0
        self.db.connection.commit()

    def test_select_employees(self):
        results = self.db.execute_query("SELECT firstName, lastName, jobTitle FROM employees;")
        assert len(results) > 0
