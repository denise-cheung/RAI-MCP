"""
Common imports and setup for UI tests module.
"""

from apps.saucedemoapp.regression.utils.logger import get_logger

# Common logger instance for all UI tests
logger = get_logger()
