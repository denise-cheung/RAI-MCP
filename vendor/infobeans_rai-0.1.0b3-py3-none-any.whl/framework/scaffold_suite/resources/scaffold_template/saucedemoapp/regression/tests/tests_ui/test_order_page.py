# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import allure
import pytest

from apps.saucedemoapp.regression.base.testbase import BaseTest
from apps.saucedemoapp.regression.utils.logger import get_logger
from apps.saucedemoapp.regression.utils.test_metadata import annotate_test_metadata
from apps.saucedemoapp.test_data_common.test_data import test_data

logger = get_logger()

@allure.parent_suite("Order Page - UI")            
# @allure.suite("Order Page")
# @allure.epic("Home Page")
@allure.epic("Order Processing")
@allure.feature("Order Management")
@pytest.mark.usefixtures("page")
class TestOrderPage(BaseTest):
    page: None

    @pytest.fixture(autouse=True)
    def setup_method(self, page):
        """Set up the test environment."""
        super().setup_method(page)
        logger.info("Setting up OrderPage tests...")
        self.login_helper.login(
            test_data["login"]["valid_credentials"]["username"],
            test_data["login"]["valid_credentials"]["password"],
        )
        logger.info("Login attempted with valid credentials, navigating to all items page.")

    @annotate_test_metadata
    @pytest.mark.xray("MYY-15", defects=["MYY-57"])
    @allure.link("https://infobeansjiraxray.atlassian.net/browse/MYY-15", name="MYY-15")    
    @allure.story("Order Creation")
    @allure.title("Create an order successfully with valid product and quantity")
    @allure.tag("ui", "order", "smoke", "regression", "MYY-15")
    def test_order_creation(self):
        """Test that an order can be created successfully."""
        order_success = self.order_helper.create_order(
            test_data["order"]["product_name"],
            test_data["order"]["quantity"],
        )
        assert order_success, "Order creation failed."
