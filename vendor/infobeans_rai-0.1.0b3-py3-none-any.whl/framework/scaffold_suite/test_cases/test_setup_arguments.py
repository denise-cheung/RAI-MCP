# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

"""
Test suite for validating setup command arguments and pre-scaffold validation.
Tests argument parsing, validation, and error handling before scaffold creation.
"""

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import typer


class TestSetupArgumentParsing:
    """Test suite for setup command argument parsing."""

    def test_parse_bool_true_values(self):
        """Test that various true-like values are correctly parsed as True."""
        from infobeans_rai import setup

        # Access the internal _parse_bool function
        def _parse_bool(val) -> bool:
            if isinstance(val, bool):
                return val
            if val is None:
                return False
            return str(val).strip().lower() in ("true", "1", "yes", "y", "on")

        # Test various true values
        true_values = [
            "true",
            "True",
            "TRUE",
            "1",
            "yes",
            "Yes",
            "YES",
            "y",
            "Y",
            "on",
            "ON",
            True,
        ]
        for value in true_values:
            assert (
                _parse_bool(value) is True
            ), f"Expected {value!r} to be parsed as True"

    def test_parse_bool_false_values(self):
        """Test that various false-like values are correctly parsed as False."""

        def _parse_bool(val) -> bool:
            if isinstance(val, bool):
                return val
            if val is None:
                return False
            return str(val).strip().lower() in ("true", "1", "yes", "y", "on")

        # Test various false values
        false_values = [
            "false",
            "False",
            "FALSE",
            "0",
            "no",
            "No",
            "NO",
            "n",
            "N",
            "off",
            "OFF",
            False,
            None,
            "",
            "random",
        ]
        for value in false_values:
            assert (
                _parse_bool(value) is False
            ), f"Expected {value!r} to be parsed as False"

    def test_parse_bool_with_whitespace(self):
        """Test that whitespace is properly handled in boolean parsing."""

        def _parse_bool(val) -> bool:
            if isinstance(val, bool):
                return val
            if val is None:
                return False
            return str(val).strip().lower() in ("true", "1", "yes", "y", "on")

        whitespace_test_cases = [
            ("  true  ", True),
            ("  yes  ", True),
            ("\ttrue\n", True),
            ("  false  ", False),
        ]
        for value, expected in whitespace_test_cases:
            assert (
                _parse_bool(value) is expected
            ), f"Expected {value!r} to be parsed as {expected}"


class TestAppNameValidation:
    """Test suite for app_name validation rules."""

    def test_valid_app_names(self):
        """Test that valid app names are accepted."""

        def _validate_folder_name(name: str, field_name: str) -> None:
            """Validate that folder name contains only alphabets, numbers, and underscores."""
            if not name:
                raise typer.Exit(1)

            import re

            if not re.match(r"^[a-zA-Z0-9_]+$", name):
                raise typer.Exit(1)

            reserved_names = [
                "CON",
                "PRN",
                "AUX",
                "NUL",
                "COM1",
                "COM2",
                "COM3",
                "COM4",
                "COM5",
                "COM6",
                "COM7",
                "COM8",
                "COM9",
                "LPT1",
                "LPT2",
                "LPT3",
                "LPT4",
                "LPT5",
                "LPT6",
                "LPT7",
                "LPT8",
                "LPT9",
            ]
            if (
                name.upper() in reserved_names
                or name.upper().split(".")[0] in reserved_names
            ):
                raise typer.Exit(1)

        # Valid app names should not raise any exceptions
        valid_names = [
            "testapp",
            "test_app",
            "TestApp",
            "test123",
            "app_123_test",
            "myapp",
            "MY_APP_2024",
            "app1",
            "test_app_v1_2_3",
            "_privateapp",
            "app_",
        ]

        for name in valid_names:
            try:
                _validate_folder_name(name, "App name")
                # If no exception raised, validation passed
                assert True
            except typer.Exit:
                pytest.fail(f"Valid app name '{name}' was rejected")

    def test_invalid_app_names_with_special_characters(self):
        """Test that app names with special characters are rejected."""
        import re
        import string

        def _validate_folder_name(name: str, field_name: str) -> None:
            if not name:
                raise typer.Exit(1)

            if not re.match(r"^[a-zA-Z0-9_]+$", name):
                raise typer.Exit(1)

            reserved_names = [
                "CON",
                "PRN",
                "AUX",
                "NUL",
                "COM1",
                "COM2",
                "COM3",
                "COM4",
                "COM5",
                "COM6",
                "COM7",
                "COM8",
                "COM9",
                "LPT1",
                "LPT2",
                "LPT3",
                "LPT4",
                "LPT5",
                "LPT6",
                "LPT7",
                "LPT8",
                "LPT9",
            ]
            if (
                name.upper() in reserved_names
                or name.upper().split(".")[0] in reserved_names
            ):
                raise typer.Exit(1)

        # Generate test cases using regex pattern for common special characters
        # Pattern includes punctuation and special characters not allowed in folder names
        special_chars = string.punctuation.replace(
            "_", ""
        )  # Exclude underscore as it's valid

        for char in special_chars:
            test_name = f"test{char}app"
            with pytest.raises(typer.Exit):
                _validate_folder_name(test_name, "App name")

        # Additional test cases with spaces and other whitespace
        whitespace_names = ["test app", "test\tapp", "test\napp"]
        for name in whitespace_names:
            with pytest.raises(typer.Exit):
                _validate_folder_name(name, "App name")

    def test_empty_app_name(self):
        """Test that empty app name is rejected."""

        def _validate_folder_name(name: str, field_name: str) -> None:
            if not name:
                raise typer.Exit(1)

            import re

            if not re.match(r"^[a-zA-Z0-9_]+$", name):
                raise typer.Exit(1)

        with pytest.raises(typer.Exit):
            _validate_folder_name("", "App name")

        with pytest.raises(typer.Exit):
            _validate_folder_name(None, "App name")

    def test_reserved_windows_names(self):
        """Test that Windows reserved names are rejected."""

        def _validate_folder_name(name: str, field_name: str) -> None:
            if not name:
                raise typer.Exit(1)

            import re

            if not re.match(r"^[a-zA-Z0-9_]+$", name):
                raise typer.Exit(1)

            reserved_names = [
                "CON",
                "PRN",
                "AUX",
                "NUL",
                "COM1",
                "COM2",
                "COM3",
                "COM4",
                "COM5",
                "COM6",
                "COM7",
                "COM8",
                "COM9",
                "LPT1",
                "LPT2",
                "LPT3",
                "LPT4",
                "LPT5",
                "LPT6",
                "LPT7",
                "LPT8",
                "LPT9",
            ]
            if (
                name.upper() in reserved_names
                or name.upper().split(".")[0] in reserved_names
            ):
                raise typer.Exit(1)

        reserved_names = [
            "CON",
            "con",
            "Con",
            "PRN",
            "prn",
            "Prn",
            "AUX",
            "aux",
            "Aux",
            "NUL",
            "nul",
            "Nul",
            "COM1",
            "com1",
            "Com1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9",
            "LPT1",
            "lpt1",
            "Lpt1",
            "LPT2",
            "LPT3",
            "LPT4",
            "LPT5",
            "LPT6",
            "LPT7",
            "LPT8",
            "LPT9",
        ]

        for name in reserved_names:
            with pytest.raises(typer.Exit):
                _validate_folder_name(name, "App name")

    def test_reserved_names_with_extension(self):
        """Test that reserved names with extensions are also rejected."""

        def _validate_folder_name(name: str, field_name: str) -> None:
            if not name:
                raise typer.Exit(1)

            import re

            if not re.match(r"^[a-zA-Z0-9_]+$", name):
                raise typer.Exit(1)

            reserved_names = [
                "CON",
                "PRN",
                "AUX",
                "NUL",
                "COM1",
                "COM2",
                "COM3",
                "COM4",
                "COM5",
                "COM6",
                "COM7",
                "COM8",
                "COM9",
                "LPT1",
                "LPT2",
                "LPT3",
                "LPT4",
                "LPT5",
                "LPT6",
                "LPT7",
                "LPT8",
                "LPT9",
            ]
            if (
                name.upper() in reserved_names
                or name.upper().split(".")[0] in reserved_names
            ):
                raise typer.Exit(1)

        # Note: These will fail regex check first due to the dot
        reserved_with_extension = [
            "CON.txt",
            "PRN.doc",
            "AUX.log",
        ]

        for name in reserved_with_extension:
            with pytest.raises(typer.Exit):
                _validate_folder_name(name, "App name")


class TestPreScaffoldValidation:
    """Test suite for validations that occur before scaffold creation."""

    @patch("infobeans_qai.create_scaffold")
    def test_validation_occurs_before_scaffold_creation(
        self, mock_create_scaffold, tmp_path, monkeypatch
    ):
        """Test that validation happens before create_scaffold is called."""
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        # Test with invalid app name - should fail validation before calling create_scaffold
        result = runner.invoke(app, ["setup", "--app", "test-app"])

        # create_scaffold should not have been called due to validation failure
        mock_create_scaffold.assert_not_called()
        assert result.exit_code != 0

    @patch("infobeans_qai.create_scaffold")
    def test_valid_arguments_passed_to_create_scaffold(
        self, mock_create_scaffold, tmp_path, monkeypatch
    ):
        """Test that valid arguments are properly passed to create_scaffold."""
        monkeypatch.chdir(tmp_path)
        mock_create_scaffold.return_value = tmp_path / "apps" / "testapp"

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        # Test with valid app name and scaffold option
        result = runner.invoke(app, ["setup", "--app", "testapp", "--scaffold", "true"])

        # Verify create_scaffold was called with correct arguments
        mock_create_scaffold.assert_called_once_with(
            "testapp", use_scaffold_template=True
        )

    @patch("infobeans_qai.create_scaffold")
    def test_scaffold_false_option_passed_correctly(
        self, mock_create_scaffold, tmp_path, monkeypatch
    ):
        """Test that scaffold=false is correctly passed to create_scaffold."""
        monkeypatch.chdir(tmp_path)
        mock_create_scaffold.return_value = tmp_path / "apps" / "simpleapp"

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        # Test with scaffold=false
        result = runner.invoke(
            app, ["setup", "--app", "simpleapp", "--scaffold", "false"]
        )

        mock_create_scaffold.assert_called_once_with(
            "simpleapp", use_scaffold_template=False
        )

    @patch("infobeans_qai.create_scaffold")
    def test_scaffold_omitted_defaults_to_false(
        self, mock_create_scaffold, tmp_path, monkeypatch
    ):
        """Test that omitting scaffold option defaults to False."""
        monkeypatch.chdir(tmp_path)
        mock_create_scaffold.return_value = tmp_path / "apps" / "defaultapp"

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        # Test without scaffold option
        result = runner.invoke(app, ["setup", "--app", "defaultapp"])

        mock_create_scaffold.assert_called_once_with(
            "defaultapp", use_scaffold_template=False
        )


class TestSetupCommandOptions:
    """Test suite for setup command options and flags."""

    def test_app_option_is_required(self):
        """Test that --app option is required."""
        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        # Running setup without --app should fail
        result = runner.invoke(app, ["setup"])

        assert result.exit_code != 0
        # Check both stdout and stderr for error message, and also check for '--app' mention
        output = (
            result.stdout + result.stderr
            if hasattr(result, "stderr")
            else result.stdout
        )
        assert (
            "Missing option" in output
            or "required" in output.lower()
            or "--app" in output
        )

    def test_app_short_flag_accepted(self, tmp_path, monkeypatch):
        """Test that -a short flag works for app option."""
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        with patch("infobeans_qai.create_scaffold") as mock_create:
            mock_create.return_value = tmp_path / "apps" / "shortflag"
            result = runner.invoke(app, ["setup", "-a", "shortflag"])

            mock_create.assert_called_once()
            assert mock_create.call_args[0][0] == "shortflag"

    def test_scaffold_short_flag_accepted(self, tmp_path, monkeypatch):
        """Test that -sc short flag works for scaffold option."""
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        with patch("infobeans_qai.create_scaffold") as mock_create:
            mock_create.return_value = tmp_path / "apps" / "scflag"
            result = runner.invoke(app, ["setup", "-a", "scflag", "-sc", "true"])

            mock_create.assert_called_once_with("scflag", use_scaffold_template=True)

    def test_scaffold_option_various_boolean_values(self, tmp_path, monkeypatch):
        """Test scaffold option with various boolean-like values."""
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        test_cases = [
            ("true", True),
            ("1", True),
            ("yes", True),
            ("y", True),
            ("on", True),
            ("false", False),
            ("0", False),
            ("no", False),
            ("n", False),
            ("off", False),
        ]

        for value, expected in test_cases:
            with patch("infobeans_qai.create_scaffold") as mock_create:
                mock_create.return_value = tmp_path / "apps" / f"app_{value}"
                result = runner.invoke(
                    app, ["setup", "-a", f"app_{value}", "--scaffold", value]
                )

                mock_create.assert_called_once()
                call_args = mock_create.call_args
                assert (
                    call_args[1]["use_scaffold_template"] == expected
                ), f"Scaffold value '{value}' should result in use_scaffold_template={expected}"


class TestArgumentCombinations:
    """Test suite for various combinations of setup command arguments."""

    def test_valid_app_with_scaffold_true(self, tmp_path, monkeypatch):
        """Test valid app name with scaffold=true."""
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        with patch("infobeans_qai.create_scaffold") as mock_create:
            mock_create.return_value = tmp_path / "apps" / "myapp"
            result = runner.invoke(
                app, ["setup", "--app", "myapp", "--scaffold", "true"]
            )

            assert result.exit_code == 0
            mock_create.assert_called_once_with("myapp", use_scaffold_template=True)
            assert (
                "Successfully set up app 'myapp' using scaffold template"
                in result.stdout
            )

    def test_valid_app_with_scaffold_false(self, tmp_path, monkeypatch):
        """Test valid app name with scaffold=false."""
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        with patch("infobeans_qai.create_scaffold") as mock_create:
            mock_create.return_value = tmp_path / "apps" / "simpleapp"
            result = runner.invoke(
                app, ["setup", "--app", "simpleapp", "--scaffold", "false"]
            )

            assert result.exit_code == 0
            mock_create.assert_called_once_with(
                "simpleapp", use_scaffold_template=False
            )
            assert (
                "Successfully set up app 'simpleapp' using minimal template"
                in result.stdout
            )

    def test_valid_app_without_scaffold_option(self, tmp_path, monkeypatch):
        """Test valid app name without scaffold option."""
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        with patch("infobeans_qai.create_scaffold") as mock_create:
            mock_create.return_value = tmp_path / "apps" / "defaultapp"
            result = runner.invoke(app, ["setup", "--app", "defaultapp"])

            assert result.exit_code == 0
            mock_create.assert_called_once_with(
                "defaultapp", use_scaffold_template=False
            )
            assert (
                "Successfully set up app 'defaultapp' using minimal template"
                in result.stdout
            )

    def test_invalid_app_with_valid_scaffold_option(self):
        """Test that invalid app name fails regardless of valid scaffold option."""
        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        with patch("infobeans_qai.create_scaffold") as mock_create:
            # Invalid app name with special characters
            result = runner.invoke(
                app, ["setup", "--app", "my-app", "--scaffold", "true"]
            )

            assert result.exit_code != 0
            mock_create.assert_not_called()

    def test_reserved_name_with_valid_scaffold_option(self):
        """Test that reserved Windows name fails regardless of valid scaffold option."""
        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        with patch("infobeans_qai.create_scaffold") as mock_create:
            result = runner.invoke(app, ["setup", "--app", "CON", "--scaffold", "true"])

            assert result.exit_code != 0
            mock_create.assert_not_called()


class TestErrorMessages:
    """Test suite for error message content and clarity."""

    def test_error_message_for_special_characters(self):
        """Test that error message is clear for special characters."""
        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()
        result = runner.invoke(app, ["setup", "--app", "test-app"])

        assert result.exit_code != 0
        # Check the combined output (stdout + stderr) as error messages go to stderr
        output = result.output if hasattr(result, "output") else result.stdout
        assert "invalid characters" in output.lower() or "error" in output.lower()

    def test_error_message_for_reserved_name(self):
        """Test that error message is clear for reserved names."""
        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()
        result = runner.invoke(app, ["setup", "--app", "CON"])

        assert result.exit_code != 0
        # Check the combined output (stdout + stderr) as error messages go to stderr
        output = result.output if hasattr(result, "output") else result.stdout
        assert "reserved" in output.lower() or "error" in output.lower()

    def test_success_message_for_scaffold_template(self, tmp_path, monkeypatch):
        """Test that success message correctly indicates scaffold template usage."""
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        with patch("infobeans_qai.create_scaffold") as mock_create:
            mock_create.return_value = tmp_path / "apps" / "testapp"
            result = runner.invoke(
                app, ["setup", "--app", "testapp", "--scaffold", "true"]
            )

            assert "scaffold template" in result.stdout
            assert "testapp" in result.stdout

    def test_success_message_for_minimal_template(self, tmp_path, monkeypatch):
        """Test that success message correctly indicates minimal template usage."""
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        with patch("infobeans_qai.create_scaffold") as mock_create:
            mock_create.return_value = tmp_path / "apps" / "simpleapp"
            result = runner.invoke(app, ["setup", "--app", "simpleapp"])

            assert "minimal template" in result.stdout
            assert "simpleapp" in result.stdout


class TestEdgeCases:
    """Test suite for edge cases and boundary conditions."""

    def test_app_name_with_only_underscores(self):
        """Test app name consisting only of underscores."""

        def _validate_folder_name(name: str, field_name: str) -> None:
            if not name:
                raise typer.Exit(1)

            import re

            if not re.match(r"^[a-zA-Z0-9_]+$", name):
                raise typer.Exit(1)

        # Should be valid as it matches the pattern
        try:
            _validate_folder_name("___", "App name")
            assert True
        except typer.Exit:
            pytest.fail("App name with only underscores should be valid")

    def test_app_name_with_only_numbers(self):
        """Test app name consisting only of numbers."""

        def _validate_folder_name(name: str, field_name: str) -> None:
            if not name:
                raise typer.Exit(1)

            import re

            if not re.match(r"^[a-zA-Z0-9_]+$", name):
                raise typer.Exit(1)

        # Should be valid as it matches the pattern
        try:
            _validate_folder_name("123456", "App name")
            assert True
        except typer.Exit:
            pytest.fail("App name with only numbers should be valid")

    def test_very_long_app_name(self, tmp_path, monkeypatch):
        """Test handling of very long app names."""
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        long_name = "a" * 255  # Maximum typical filename length

        with patch("infobeans_qai.create_scaffold") as mock_create:
            mock_create.return_value = tmp_path / "apps" / long_name
            result = runner.invoke(app, ["setup", "--app", long_name])

            # Should succeed as long as it meets other validation criteria
            mock_create.assert_called_once()

    def test_single_character_app_name(self, tmp_path, monkeypatch):
        """Test single character app names."""
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner

        from infobeans_rai import app

        runner = CliRunner()

        with patch("infobeans_qai.create_scaffold") as mock_create:
            mock_create.return_value = tmp_path / "apps" / "a"
            result = runner.invoke(app, ["setup", "--app", "a"])

            assert result.exit_code == 0
            mock_create.assert_called_once_with("a", use_scaffold_template=False)

    def test_mixed_case_reserved_names(self):
        """Test reserved names with various case combinations."""

        def _validate_folder_name(name: str, field_name: str) -> None:
            if not name:
                raise typer.Exit(1)

            import re

            if not re.match(r"^[a-zA-Z0-9_]+$", name):
                raise typer.Exit(1)

            reserved_names = [
                "CON",
                "PRN",
                "AUX",
                "NUL",
                "COM1",
                "COM2",
                "COM3",
                "COM4",
                "COM5",
                "COM6",
                "COM7",
                "COM8",
                "COM9",
                "LPT1",
                "LPT2",
                "LPT3",
                "LPT4",
                "LPT5",
                "LPT6",
                "LPT7",
                "LPT8",
                "LPT9",
            ]
            if (
                name.upper() in reserved_names
                or name.upper().split(".")[0] in reserved_names
            ):
                raise typer.Exit(1)

        mixed_case_reserved = ["CoN", "pRn", "AuX", "nUl", "cOm1", "LpT1"]

        for name in mixed_case_reserved:
            with pytest.raises(typer.Exit):
                _validate_folder_name(name, "App name")

    def test_unicode_characters_in_app_name(self):
        """Test that unicode/international characters are rejected."""

        def _validate_folder_name(name: str, field_name: str) -> None:
            if not name:
                raise typer.Exit(1)

            import re

            if not re.match(r"^[a-zA-Z0-9_]+$", name):
                raise typer.Exit(1)

        unicode_names = [
            "café",  # French
            "naïve",  # Diacritic
            "日本語",  # Japanese
            "Привет",  # Russian
            "مرحبا",  # Arabic
            "test_ñ",  # Spanish
            "test_ü",  # German
        ]

        for name in unicode_names:
            with pytest.raises(typer.Exit):
                _validate_folder_name(name, "App name")
