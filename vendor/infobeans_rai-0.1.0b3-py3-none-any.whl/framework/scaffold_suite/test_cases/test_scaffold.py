# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

from pathlib import Path

import pytest

from framework.scaffold_suite.scaffold import (
    _find_template_app_path,
    _replace_placeholders_in_file,
    _replace_references_in_file,
    create_scaffold,
)


class TestPlaceholderReplacement:
    def test_replace_app_name_in_file(self, tmp_path):
        # Create a test file with placeholders
        test_file = tmp_path / "test.py"
        test_file.write_text("from apps.app_name.pages import Page")

        replacements = {"app_name": "myapp"}
        _replace_placeholders_in_file(test_file, replacements)

        assert test_file.read_text() == "from apps.myapp.pages import Page"

    def test_replace_multiple_occurrences(self, tmp_path):
        test_file = tmp_path / "config.yaml"
        test_file.write_text("app: app_name\npath: /app_name/tests")

        replacements = {"app_name": "testapp"}
        _replace_placeholders_in_file(test_file, replacements)

        content = test_file.read_text()
        assert "testapp" in content
        assert "app_name" not in content


class TestReferenceReplacement:
    def test_replace_import_statements(self, tmp_path):
        test_file = tmp_path / "test.py"
        test_file.write_text("from saucedemo.pages.login_page import LoginPage")

        replacements = {r"\bfrom saucedemo\.": "from myapp."}
        _replace_references_in_file(test_file, replacements)

        assert "from myapp.pages.login_page" in test_file.read_text()

    def test_replace_apps_prefix_imports(self, tmp_path):
        test_file = tmp_path / "conftest.py"
        test_file.write_text("from apps.saucedemo.tests import helpers")

        replacements = {r"\bapps\.saucedemo\.tests\b": "apps.newapp.tests"}
        _replace_references_in_file(test_file, replacements)

        assert "apps.newapp.tests" in test_file.read_text()


class TestScaffoldCreation:
    @pytest.fixture
    def clean_workspace(self, tmp_path, monkeypatch):
        # Change working directory to temp path
        monkeypatch.chdir(tmp_path)
        return tmp_path

    def test_create_scaffold_from_template(self, clean_workspace):
        from framework.scaffold_suite.scaffold import create_scaffold

        app_name = "testapp"
        output = create_scaffold(app_name, use_scaffold_template=True)

        # Verify directory structure
        assert output.exists()
        assert (output / "tests").exists()
        assert (output / "pages").exists()
        assert (output / "__init__.py").exists()

        # Verify apps/__init__.py exists
        apps_init = clean_workspace / "apps" / "__init__.py"
        assert apps_init.exists()

    def test_create_scaffold_from_simple_template(self, clean_workspace):
        from framework.scaffold_suite.scaffold import create_scaffold

        app_name = "simpleapp"
        output = create_scaffold(app_name, use_scaffold_template=False)

        assert output.exists()
        # Verify expected files exist
        assert (output / "config.yaml").exists()

    def test_placeholder_replacement_in_created_files(self, clean_workspace):
        app_name = "myapp"
        output = create_scaffold(app_name, use_scaffold_template=True)

        # Check that placeholders were replaced in actual files
        test_files = list(output.glob("**/*.py"))
        for test_file in test_files:
            content = test_file.read_text()
            # Original template name should not exist
            assert "saucedemo" not in content or f"from apps.{app_name}" in content

    def test_import_statements_updated(self, clean_workspace):
        app_name = "customapp"
        output = create_scaffold(app_name, use_scaffold_template=True)

        # Find test files and verify imports
        test_file = next(output.glob("**/test_*.py"))
        content = test_file.read_text()

        # Should have app_name in imports, not template name
        assert f"from {app_name}." in content or f"from apps.{app_name}." in content
        assert "from saucedemo." not in content
